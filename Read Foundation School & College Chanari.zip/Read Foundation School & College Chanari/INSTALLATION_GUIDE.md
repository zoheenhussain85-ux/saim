# Foundation School & College Chanari - Website Setup Guide

## Project Overview
Website for **Foundation School & College, Chanari** established on December 7, 1994, under Foundation Trust, offering English version curriculum.

## File Structure
```
foundation-school-chanari/
├── index.html          # Main website frontend
├── sql/
│   └── schema.sql      # Database schema
├── api/
│   ├── config.php      # Database configuration
│   ├── news.php        # News API endpoint
│   ├── gallery.php     # Photo gallery API endpoint
│   ├── events.php      # Events API endpoint
│   ├── staff.php       # Staff directory API endpoint
│   ├── admission.php   # Online admission form API
│   └── contact.php     # Contact form API
├── uploads/            # Uploaded images directory
└── INSTALLATION_GUIDE.md
```

## Prerequisites
1. **Web Server**: XAMPP, WAMP, or MAMP (Apache + MySQL + PHP)
2. **Database**: MySQL 5.7+ or MariaDB
3. **PHP**: Version 7.4 or higher

## Step-by-Step Installation

### Step 1: Setup XAMPP/WAMP
1. Download and install XAMPP from https://www.apachefriends.org/
2. Start Apache and MySQL services
3. Place this project folder in `C:\xampp\htdocs\` (or `/Applications/XAMPP/htdocs/` on Mac)

### Step 2: Create Database
1. Open browser and go to `http://localhost/phpmyadmin`
2. Click "Databases" tab
3. Create new database named: `foundation_school_chanari`
4. Click "Create"

### Step 3: Import Schema
1. In phpMyAdmin, select the `foundation_school_chanari` database
2. Click "Import" tab
3. Browse to `sql/schema.sql` file
4. Click "Go" to import all tables

### Step 4: Configure Database Connection
1. Open `api/config.php`
2. Update credentials if needed:
   ```php
   $host = "localhost";
   $db = "foundation_school_chanari";
   $user = "root";      // default XAMPP user
   $pass = "";          // default XAMPP has no password
   $port = 3306;
   ```
3. Save the file

### Step 5: Run the Website
1. Open browser and go to `http://localhost/foundation-school-chanari/` (or your folder name)
2. The website will automatically load all data from the database

## API Endpoints

### News API (`api/news.php`)
- Returns all published news items
- Columns: id, title, content, image_url, category, published_by, published_at, status, published_by_name

### Gallery API (`api/gallery.php`)
- Returns all gallery images
- Columns: id, title, description, image_url, category, uploaded_by, uploaded_at, uploaded_by_name

### Events API (`api/events.php`)
- Returns upcoming events only
- Columns: id, title, description, event_date, event_time, location, image_url, category, created_by, created_at, status, created_by_name

### Staff API (`api/staff.php`)
- Returns active staff members
- Columns: id, user_id, qualification, subject, joining_date, experience_years, email, phone, image_url, status, user_name (from users join)

### Admission Form (`api/admission.php`)
- POST parameters: full_name, email, phone, current_class, applying_for_class, dob, gender, address, parent_name, previous_school, comments
- Returns success/failure message

### Contact Form (`api/contact.php`)
- POST parameters: name, email, message
- Returns success/failure message

## Database Tables Description

### 1. users
- Stores admin/staff login credentials
- Fields: id, username, password, full_name, role, email, phone, address, profile_image, created_at

### 2. staff
- Detailed staff information linked to users
- Fields: id, user_id (FK), qualification, subject, joining_date, experience_years, email, phone, image_url, status

### 3. news
- School news and announcements
- Fields: id, title, content, image_url, category, published_by (FK), published_at, status

### 4. gallery
- Photo gallery management
- Fields: id, title, description, image_url, category, uploaded_by (FK), uploaded_at

### 5. events
- School events and functions
- Fields: id, title, description, event_date (NOT date!), event_time, location, image_url, category, created_by (FK), created_at, status

### 6. admission_inquiries
- Online admission form submissions
- Fields: id, full_name, email, phone, current_class, applying_for_class, date_of_birth, gender, address, parent_name, previous_school, comments, submitted_at, status, ip_address

### 7. settings
- School configuration (pre-populated with your details)
- Fields: id, school_name, school_address, phone, email, website, established_year, trust_name, curriculum, principal_name, updated_at

## Customizing Your Website

### Adding School Information
1. Update the `settings` table in phpMyAdmin
2. Or directly modify `index.html` to hardcode your information

### Adding News
1. Insert into `news` table via phpMyAdmin, or
2. Use the admin panel (can be developed further)

### Adding Photos to Gallery
1. Place images in `uploads/` folder
2. Insert record into `gallery` table with image path (e.g., `uploads/event1.jpg`)

### Adding Events
1. Insert into `events` table via phpMyAdmin
2. Ensure `event_date` format is `YYYY-MM-DD`

### Managing Staff
1. Add users to `users` table first
2. Add staff records linked to user IDs

### Processing Admission Forms
1. Form submissions go into `admission_inquiries` table
2. Status can be updated: new → viewed → contacted → admitted/rejected

## Security Notes
1. Change default `root` MySQL password in `config.php` for production
2. Consider adding authentication for admin functions
3. Validate and sanitize all form inputs
4. Limit file upload types in production
5. Regular database backups recommended

## Browser Compatibility
- Chrome, Firefox, Safari, Edge (latest versions)
- Mobile responsive design for tablets and phones

## Need Help?
- Check XAMPP Apache/PHP error logs
- Ensure `pdo` extension is enabled in PHP
- Verify database table prefixes match between schema and PHP code
- Contact: support@fsnchanari.edu (placeholder - replace with actual)

## Established Details
- **School Name**: Foundation School & College
- **Location**: Chanari
- **Established**: December 7, 1994
- **Trust**: Foundation Trust
- **Curriculum**: English Version