<?php
// test_reports.php - Test Reports page for Foundation School & College Chanari
// Load test reports data from API
$reports_data = file_get_contents('api/test_reports.php?action=list');
$reports = json_decode($reports_data, true);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Reports - Foundation School & College Chanari</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f5f7fa; }
        nav { background: #2c3e50; padding: 1rem 2rem; position: fixed; width: 100%; top: 0; z-index: 1000; }
        nav .logo { color: white; font-size: 1.5rem; font-weight: bold; margin-right: 2rem; }
        nav a { color: white; text-decoration: none; margin-left: 2rem; font-weight: 500; }
        nav a.active { color: #e74c3c; }
        nav a:hover { color: #e74c3c; }
        .hero { background: linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), url('https://via.placeholder.com/1920x1080/2c3e50/ffffff?text=Foundation+School'); 
                background-size: cover; background-position: center; height: 60px; margin-top: 60px; margin-bottom: 40px; display: flex; align-items: center; justify-content: center; text-align: center; color: white; }
        .container { max-width: 1200px; margin: 0 auto; padding: 0 20px; }
        .section { background: white; margin-bottom: 30px; padding: 30px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        .section h2 { color: #2c3e50; margin-bottom: 20px; border-bottom: 2px solid #eee; padding-bottom: 10px; }
        .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; }
        .card { background: #f8f9fa; padding: 20px; border-radius: 5px; text-align: center; transition: transform 0.3s; }
        .card:hover { transform: translateY(-5px); }
        .card img { max-width: 100%; height: 200px; object-fit: cover; border-radius: 4px; margin-bottom: 15px; }
        .card h3 { margin-bottom: 10px; color: #2c3e50; }
        .card p { color: #666; font-size: 0.9rem; }
        .badge { display: inline-block; background: #e74c3c; color: white; padding: 3px 8px; border-radius: 4px; font-size: 0.8rem; margin-left: 10px; }
        form { max-width: 500px; }
        input, textarea, select { width: 100%; padding: 10px; margin: 5px 0; border: 1px solid #ddd; border-radius: 4px; }
        button { width: 100%; padding: 10px; background: #3498db; color: white; border: none; cursor: pointer; font-size: 1rem; margin-top: 10px; }
        @media (max-width: 768px) { nav a { display: block; margin: 10px 0; } }
    </style>
</head>
<body>
    <nav>
        <div class="logo">FS&C Chanari</div>
        <a href="about.php" class="<?= basename($_SERVER['PHP_SELF']) === 'about.php' ? 'active' : '' ?>">About</a>
        <a href="news.php" class="<?= basename($_SERVER['PHP_SELF']) === 'news.php' ? 'active' : '' ?>">News</a>
        <a href="gallery.php" class="<?= basename($_SERVER['PHP_SELF']) === 'gallery.php' ? 'active' : '' ?>">Photo</a>
        <a href="events.php" class="<?= basename($_SERVER['PHP_SELF']) === 'events.php' ? 'active' : '' ?>">Events</a>
        <a href="staff.php" class="<?= basename($_SERVER['PHP_SELF']) === 'staff.php' ? 'active' : '' ?>">Staff</a>
        <a href="admission.php" class="<?= basename($_SERVER['PHP_SELF']) === 'admission.php' ? 'active' : '' ?>">Admission</a>
        <a href="test_reports.php" class="<?= basename($_SERVER['PHP_SELF']) === 'test_reports.php' ? 'active' : '' ?>">Test Reports</a>
    </nav>
    
    <div class="hero">
        <div>
            <h1>Foundation School & College</h1>
            <p>Chanari • Established December 7, 1994 • English Version • Foundation Trust</p>
        </div>
    </div>
    
    <div class="container">
        <section id="test-reports" class="section">
            <h2>Student Test Reports</h2>
            
            <div style="background: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                <h3 style="margin-top: 0;">Search Student Test Reports</h3>
                <div style="margin-bottom: 15px;">
                    <input type="text" id="student-search" placeholder="Search student by name or admission ID..." onkeyup="searchStudents(this.value)" style="padding: 8px; width: 300px; border: 1px solid #ddd; border-radius: 4px;">
                    <select id="class-filter" onchange="filterByClass(this.value)" style="padding: 8px; margin-left: 10px; border: 1px solid #ddd; border-radius: 4px;">
                        <option value="">All Classes</option>
                        <option value="Playgroup">Playgroup</option>
                        <option value="Nursery">Nursery</option>
                        <option value="Class 1">Class 1</option>
                        <option value="Class 5">Class 5</option>
                        <option value="Class 9">Class 9</option>
                        <option value="Class 11">Class 11</option>
                    </select>
                </div>
            </div>
            
            <div class="grid" id="test-reports-container">
                <?php if (empty($reports)): ?>
                    <p>No test reports found. Please check the database.</p>
                <?php else: ?>
                    <?php foreach ($reports as $r): ?>
                        <div class="card">
                            <h3><?= htmlspecialchars($r['student_name'] ?? 'Unknown') ?> - <?= htmlspecialchars($r['test_name'] ?? 'Unknown') ?></h3>
                            <p>Class: <?= htmlspecialchars($r['class_name'] ?? 'N/A') ?></p>
                            <p>Section: <?= htmlspecialchars($r['section'] ?? 'N/A') ?></p>
                            <p>Roll No: <?= htmlspecialchars($r['roll_no'] ?? 'N/A') ?></p>
                            <p>Marks: <?= htmlspecialchars($r['marks_obtained'] ?? '0') ?>/<?= htmlspecialchars($r['total_marks'] ?? '100') ?> (<?= htmlspecialchars($r['percentage'] ?? '0.00') ?>%)</p>
                            <p>Grade: <?= htmlspecialchars($r['grade'] ?? 'F') ?></p>
                            <p>Date: <?= htmlspecialchars($r['report_date'] ?? 'N/A') ?></p>
                            <p><?= htmlspecialchars($r['remarks'] ?? '') ?></p>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </section>
    </div>
    
    <script>
        // Search students by name or admission ID
        async function searchStudents(term) {
            const response = await fetch('api/test_reports.php?action=search_students&term=' + term);
            const students = await response.json();
            console.log('Search results:', students);
        }
        
        // Filter test reports by class
        async function filterByClass(className) {
            const response = await fetch('api/test_reports.php?action=list&class=' + className);
            const reports = await response.json();
            const container = document.getElementById('test-reports-container');
            container.innerHTML = reports.map(r => `
                <div class="card">
                    <h3>${r.student_name} - ${r.test_name}</h3>
                    <p>Class: ${r.class_name || 'N/A'}</p>
                    <p>Section: ${r.section || 'N/A'}</p>
                    <p>Roll No: ${r.roll_no || 'N/A'}</p>
                    <p>Marks: ${r.marks_obtained}/${r.total_marks} (${r.percentage}%)</p>
                    <p>Grade: ${r.grade}</p>
                    <p>Date: ${r.report_date}</p>
                    <p>${r.remarks}</p>
                </div>
            `).join('');
        }
    </script>
</body>
</html>