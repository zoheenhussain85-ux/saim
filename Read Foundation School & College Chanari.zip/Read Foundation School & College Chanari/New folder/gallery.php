<?php
// gallery.php - Photo gallery page for Foundation School & College Chanari
// Load gallery data from API
$gallery_data = file_get_contents('api/gallery.php');
$photos = json_decode($gallery_data, true);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Photo Gallery - Foundation School & College Chanari</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f5f7fa; }
        nav { background: #2c3e50; padding: 1rem 2rem; position: fixed; width: 100%; top: 0; z-index: 1000; }
        nav .logo { color: white; font-size: 1.5rem; font-weight: bold; margin-right: 2rem; }
        nav a { color: white; text-decoration: none; margin-left: 2rem; font-weight: 500; }
        nav a.active { color: #e74c3c; }
        nav a:hover { color: #e74c3c; }
        .hero { background: linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), url('https://via.placeholder.com/1920x1080/2c3e50/ffffff?text=Foundation+School'); 
                background-size: cover; background-position: center; height: 60px; margin-top: 60px; margin-bottom: 40px; display: flex; align-items: center; justify-content: center; text-align: center; color: white; }
        .container { max-width: 1200px; margin: 0 auto; padding: 0 20px; }
        .section { background: white; margin-bottom: 30px; padding: 30px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        .section h2 { color: #2c3e50; margin-bottom: 20px; border-bottom: 2px solid #eee; padding-bottom: 10px; }
        .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; }
        .card { background: #f8f9fa; padding: 20px; border-radius: 5px; text-align: center; transition: transform 0.3s; }
        .card:hover { transform: translateY(-5px); }
        .card img { max-width: 100%; height: 200px; object-fit: cover; border-radius: 4px; margin-bottom: 15px; }
        .card h3 { margin-bottom: 10px; color: #2c3e50; }
        .card p { color: #666; font-size: 0.9rem; }
        .badge { display: inline-block; background: #e74c3c; color: white; padding: 3px 8px; border-radius: 4px; font-size: 0.8rem; margin-left: 10px; }
        @media (max-width: 768px) { nav a { display: block; margin: 10px 0; } }
    </style>
</head>
<body>
    <nav>
        <div class="logo">FS&C Chanari</div>
        <a href="about.php" class="<?= basename($_SERVER['PHP_SELF']) === 'about.php' ? 'active' : '' ?>">About</a>
        <a href="news.php" class="<?= basename($_SERVER['PHP_SELF']) === 'news.php' ? 'active' : '' ?>">News</a>
        <a href="gallery.php" class="<?= basename($_SERVER['PHP_SELF']) === 'gallery.php' ? 'active' : '' ?>">Photo</a>
        <a href="events.php" class="<?= basename($_SERVER['PHP_SELF']) === 'events.php' ? 'active' : '' ?>">Events</a>
        <a href="staff.php" class="<?= basename($_SERVER['PHP_SELF']) === 'staff.php' ? 'active' : '' ?>">Staff</a>
        <a href="admission.php" class="<?= basename($_SERVER['PHP_SELF']) === 'admission.php' ? 'active' : '' ?>">Admission</a>
        <a href="test_reports.php" class="<?= basename($_SERVER['PHP_SELF']) === 'test_reports.php' ? 'active' : '' ?>">Test Reports</a>
    </nav>
    
    <div class="hero">
        <div>
            <h1>Foundation School & College</h1>
            <p>Chanari • Established December 7, 1994 • English Version • Foundation Trust</p>
        </div>
    </div>
    
    <div class="container">
        <section id="photo" class="section">
            <h2>Photo Gallery</h2>
            <div class="grid" id="photo-grid">
                <?php if (empty($photos)): ?>
                    <p>No gallery images found. Please check the database.</p>
                <?php else: ?>
                    <?php foreach ($photos as $p): ?>
                        <div class="card">
                            <img src="uploads/<?= htmlspecialchars($p['image_url']) ?>" alt="<?= htmlspecialchars($p['title']) ?>">
                            <h3><?= htmlspecialchars($p['title']) ?></h3>
                            <p><?= htmlspecialchars($p['description']) ?></p>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </section>
    </div>
</body>
</html>