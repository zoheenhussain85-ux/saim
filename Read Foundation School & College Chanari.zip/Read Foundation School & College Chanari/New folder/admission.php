<?php
// admission.php - Admission form page for Foundation School & College Chanari
// Process admission form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Simple form processing - in production, validate and sanitize all inputs
    $full_name = $_POST['full_name'] ?? '';
    $email = $_POST['email'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $current_class = $_POST['current_class'] ?? '';
    $applying_for_class = $_POST['applying_for_class'] ?? '';
    $dob = $_POST['dob'] ?? '';
    $gender = $_POST['gender'] ?? '';
    $address = $_POST['address'] ?? '';
    $parent_name = $_POST['parent_name'] ?? '';
    $previous_school = $_POST['previous_school'] ?? '';
    $comments = $_POST['comments'] ?? '';
    
    // Here you would typically insert into the admission_inquiries table
    // For now, just show a success message
    $success = true;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admission - Foundation School & College Chanari</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f5f7fa; }
        nav { background: #2c3e50; padding: 1rem 2rem; position: fixed; width: 100%; top: 0; z-index: 1000; }
        nav .logo { color: white; font-size: 1.5rem; font-weight: bold; margin-right: 2rem; }
        nav a { color: white; text-decoration: none; margin-left: 2rem; font-weight: 500; }
        nav a.active { color: #e74c3c; }
        nav a:hover { color: #e74c3c; }
        .hero { background: linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), url('https://via.placeholder.com/1920x1080/2c3e50/ffffff?text=Foundation+School'); 
                background-size: cover; background-position: center; height: 60px; margin-top: 60px; margin-bottom: 40px; display: flex; align-items: center; justify-content: center; text-align: center; color: white; }
        .container { max-width: 1200px; margin: 0 auto; padding: 0 20px; }
        .section { background: white; margin-bottom: 30px; padding: 30px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        .section h2 { color: #2c3e50; margin-bottom: 20px; border-bottom: 2px solid #eee; padding-bottom: 10px; }
        .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; }
        .card { background: #f8f9fa; padding: 20px; border-radius: 5px; text-align: center; transition: transform 0.3s; }
        .card:hover { transform: translateY(-5px); }
        .card img { max-width: 100%; height: 200px; object-fit: cover; border-radius: 4px; margin-bottom: 15px; }
        .card h3 { margin-bottom: 10px; color: #2c3e50; }
        .card p { color: #666; font-size: 0.9rem; }
        .badge { display: inline-block; background: #e74c3c; color: white; padding: 3px 8px; border-radius: 4px; font-size: 0.8rem; margin-left: 10px; }
        form { max-width: 500px; }
        input, textarea, select { width: 100%; padding: 10px; margin: 5px 0; border: 1px solid #ddd; border-radius: 4px; }
        button { width: 100%; padding: 10px; background: #3498db; color: white; border: none; cursor: pointer; font-size: 1rem; margin-top: 10px; }
        @media (max-width: 768px) { nav a { display: block; margin: 10px 0; } }
    </style>
</head>
<body>
    <nav>
        <div class="logo">FS&C Chanari</div>
        <a href="about.php" class="<?= basename($_SERVER['PHP_SELF']) === 'about.php' ? 'active' : '' ?>">About</a>
        <a href="news.php" class="<?= basename($_SERVER['PHP_SELF']) === 'news.php' ? 'active' : '' ?>">News</a>
        <a href="gallery.php" class="<?= basename($_SERVER['PHP_SELF']) === 'gallery.php' ? 'active' : '' ?>">Photo</a>
        <a href="events.php" class="<?= basename($_SERVER['PHP_SELF']) === 'events.php' ? 'active' : '' ?>">Events</a>
        <a href="staff.php" class="<?= basename($_SERVER['PHP_SELF']) === 'staff.php' ? 'active' : '' ?>">Staff</a>
        <a href="admission.php" class="<?= basename($_SERVER['PHP_SELF']) === 'admission.php' ? 'active' : '' ?>">Admission</a>
        <a href="test_reports.php" class="<?= basename($_SERVER['PHP_SELF']) === 'test_reports.php' ? 'active' : '' ?>">Test Reports</a>
    </nav>
    
    <div class="hero">
        <div>
            <h1>Foundation School & College</h1>
            <p>Chanari • Established December 7, 1994 • English Version • Foundation Trust</p>
        </div>
    </div>
    
    <div class="container">
        <section id="admission" class="section">
            <h2>Online Admission</h2>
            <p>Foundation School & College welcomes admissions for the upcoming academic session. Established in 1994, we offer English version curriculum from playgroup to higher secondary levels.</p>
            
            <?php if (!empty($success)): ?>
                <div style="background: #d4edda; padding: 20px; border-radius: 8px; margin-bottom: 20px; border: 1px solid #c3e6cb;">
                    <h3 style="margin-top: 0;">Application Submitted Successfully!</h3>
                    <p>Your admission application has been received. Our admissions team will contact you shortly.</p>
                </div>
            <?php endif; ?>
            
            <form id="admission-form" method="POST" action="">
                <input type="text" name="full_name" placeholder="Student Name" required>
                <input type="email" name="email" placeholder="Parent Email" required>
                <input type="tel" name="phone" placeholder="Phone Number" required>
                <select name="applying_for_class" required>
                    <option value="" disabled selected>Select Class</option>
                    <option value="Playgroup">Playgroup</option>
                    <option value="Nursery">Nursery</option>
                    <option value="Class 1">Class 1</option>
                    <option value="Class 6">Class 6</option>
                    <option value="Class 9">Class 9</option>
                    <option value="Class 11">Class 11</option>
                </select>
                <input type="date" name="dob">
                <select name="gender">
                    <option value="" disabled selected>Gender</option>
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                    <option value="other">Other</option>
                </select>
                <textarea name="comments" rows="3" placeholder="Additional Comments"></textarea>
                <button type="submit">Submit Application</button>
            </form>
            
            <p><strong>Established:</strong> December 7, 1994</p>
            <p><strong>Curriculum:</strong> English Version</p>
            <p><strong>Management:</strong> Foundation Trust</p>
        </section>
    </div>
</body>
</html>