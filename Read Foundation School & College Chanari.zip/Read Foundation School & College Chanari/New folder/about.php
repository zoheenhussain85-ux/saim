<?php
// about.php - About page for Foundation School & College Chanari
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - Foundation School & College Chanari</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f5f7fa; }
        nav { background: #2c3e50; padding: 1rem 2rem; position: fixed; width: 100%; top: 0; z-index: 1000; }
        nav .logo { color: white; font-size: 1.5rem; font-weight: bold; margin-right: 2rem; }
        nav a { color: white; text-decoration: none; margin-left: 2rem; font-weight: 500; }
        nav a.active { color: #e74c3c; }
        nav a:hover { color: #e74c3c; }
        .hero { background: linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), url('https://via.placeholder.com/1920x1080/2c3e50/ffffff?text=Foundation+School'); 
                background-size: cover; background-position: center; height: 600px; margin-top: 60px; margin-bottom: 40px; display: flex; align-items: center; justify-content: center; text-align: center; color: white; }
        .hero h1 { font-size: 3rem; margin-bottom: 1rem; }
        .hero p { font-size: 1.2rem; max-width: 600px; }
        .container { max-width: 1200px; margin: 0 auto; padding: 0 20px; }
        .section { background: white; margin-bottom: 30px; padding: 30px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        .section h2 { color: #2c3e50; margin-bottom: 20px; border-bottom: 2px solid #eee; padding-bottom: 10px; }
        .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; }
        .card { background: #f8f9fa; padding: 20px; border-radius: 5px; text-align: center; transition: transform 0.3s; }
        .card:hover { transform: translateY(-5px); }
        .card img { max-width: 100%; height: 200px; object-fit: cover; border-radius: 4px; margin-bottom: 15px; }
        .card h3 { margin-bottom: 10px; color: #2c3e50; }
        .card p { color: #666; font-size: 0.9rem; }
        .badge { display: inline-block; background: #e74c3c; color: white; padding: 3px 8px; border-radius: 4px; font-size: 0.8rem; margin-left: 10px; }
        @media (max-width: 768px) { .hero h1 { font-size: 2rem; } nav a { display: block; margin: 10px 0; } }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f5f7fa; }
        nav { background: #2c3e50; padding: 1rem 2rem; position: fixed; width: 100%; top: 0; z-index: 1000; }
        nav .logo { color: white; font-size: 1.5rem; font-weight: bold; margin-right: 2rem; }
        nav a { color: white; text-decoration: none; margin-left: 2rem; font-weight: 500; }
        nav a.active { color: #e74c3c; }
        nav a:hover { color: #e74c3c; }
        .hero { background: linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), url('https://via.placeholder.com/1920x1080/2c3e50/ffffff?text=Foundation+School'); 
                background-size: cover; background-position: center; height: 60px; margin-top: 60px; margin-bottom: 40px; display: flex; align-items: center; justify-content: center; text-align: center; color: white; }
        .container { max-width: 1200px; margin: 0 auto; padding: 0 20px; }
        .section { background: white; margin-bottom: 30px; padding: 30px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        .section h2 { color: #2c3e50; margin-bottom: 20px; border-bottom: 2px solid #eee; padding-bottom: 10px; }
        .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; }
        .card { background: #f8f9fa; padding: 20px; border-radius: 5px; text-align: center; transition: transform 0.3s; }
        .card:hover { transform: translateY(-5px); }
        .card img { max-width: 100%; height: 200px; object-fit: cover; border-radius: 4px; margin-bottom: 15px; }
        .card h3 { margin-bottom: 10px; color: #2c3e50; }
        .card p { color: #666; font-size: 0.9rem; }
        .badge { display: inline-block; background: #e74c3c; color: white; padding: 3px 8px; border-radius: 4px; font-size: 0.8rem; margin-left: 10px; }
        form { max-width: 500px; }
        input, textarea, select { width: 100%; padding: 10px; margin: 5px 0; border: 1px solid #ddd; border-radius: 4px; }
        button { width: 100%; padding: 10px; background: #3498db; color: white; border: none; cursor: pointer; font-size: 1rem; margin-top: 10px; }
        @media (max-width: 768px) { nav a { display: block; ma
    </style>
</head>
<body>
    <nav>
        <div class="logo">FS&C Chanari</div>
        <a href="about.php" class="<?= basename($_SERVER['PHP_SELF']) === 'about.php' ? 'active' : '' ?>">About</a>
        <a href="news.php" class="<?= basename($_SERVER['PHP_SELF']) === 'news.php' ? 'active' : '' ?>">News</a>
        <a href="gallery.php" class="<?= basename($_SERVER['PHP_SELF']) === 'gallery.php' ? 'active' : '' ?>">Photo</a>
        <a href="events.php" class="<?= basename($_SERVER['PHP_SELF']) === 'events.php' ? 'active' : '' ?>">Events</a>
        <a href="staff.php" class="<?= basename($_SERVER['PHP_SELF']) === 'staff.php' ? 'active' : '' ?>">Staff</a>
        <a href="admission.php" class="<?= basename($_SERVER['PHP_SELF']) === 'admission.php' ? 'active' : '' ?>">Admission</a>
        <a href="test_reports.php" class="<?= basename($_SERVER['PHP_SELF']) === 'test_reports.php' ? 'active' : '' ?>">Test Reports</a>
    </nav>
    
    <div class="hero">
        <div>
            <h1>Foundation School & College</h1>
            <p>Chanari • Established December 7, 1994 • English Version • Foundation Trust</p>
        </div>
    </div>
    
    <div class="container">
        <!-- About Section -->
        <section id="about" class="section">
            <h2>About Us</h2>
            <p>Foundation School & College Chanari was established on December 7, 1994, under the aegis of Foundation Trust. We are a pioneering English version educational institution situated in Chanari, committed to providing quality education from foundation level through higher secondary. Since our inception, we have been dedicated to academic excellence, character development, and holistic growth of our students.</p>
            <p>Our mission is to nurture young minds with knowledge, skills, and values that empower them to succeed in a rapidly changing world while staying grounded in their cultural heritage.</p>
            <p>Since 1994, our school has grown to become a leading educational institution in the region, serving the community with distinction and commitment to excellence.</p>
        </section>
    </div>
</body>
</html>