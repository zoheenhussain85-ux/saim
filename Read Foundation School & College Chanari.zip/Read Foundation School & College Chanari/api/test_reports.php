<?php
require 'config.php';

header('Content-Type: application/json');

function grade_for($percentage) {
    if ($percentage >= 80) return 'A+';
    if ($percentage >= 70) return 'A';
    if ($percentage >= 60) return 'B';
    if ($percentage >= 50) return 'C';
    if ($percentage >= 40) return 'D';
    return 'F';
}

$action = $_GET['action'] ?? 'list';

// Handle both JSON and form data
$contentType = $_SERVER['CONTENT_TYPE'] ?? '';
$student_id = '';
$test_id = '';
$marks_obtained = '';
$total_marks = '';
$percentage = '';
$remarks = '';
$test_name = '';
$subject = '';
$class_level = '';
$passing_marks = '';
$test_date = '';
$description = '';
$section = '';
$group_name = '';
$image_url = '';

if (strpos($contentType, 'application/json') !== false) {
    // JSON input
    $body = file_get_contents('php://input');
    $data = json_decode($body, true);
    $student_id = $data['student_id'] ?? '';
    $test_id = $data['test_id'] ?? '';
    $marks_obtained = $data['marks_obtained'] ?? '';
    $total_marks = $data['total_marks'] ?? '';
    $percentage = $data['percentage'] ?? '';
    $remarks = $data['remarks'] ?? '';
    $test_name = $data['test_name'] ?? '';
    $subject = $data['subject'] ?? '';
    $class_level = $data['class_level'] ?? '';
    $passing_marks = $data['passing_marks'] ?? '';
    $test_date = $data['test_date'] ?? '';
    $description = $data['description'] ?? '';
    $section = $data['section'] ?? '';
    $group_name = $data['group_name'] ?? '';
    $image_url = $data['image_url'] ?? '';
} else {
    // Form input
    $student_id = $_POST['student_id'] ?? '';
    $test_id = $_POST['test_id'] ?? '';
    $marks_obtained = $_POST['marks_obtained'] ?? '';
    $total_marks = $_POST['total_marks'] ?? '';
    $percentage = $_POST['percentage'] ?? '';
    $remarks = $_POST['remarks'] ?? '';
    $test_name = $_POST['test_name'] ?? '';
    $subject = $_POST['subject'] ?? '';
    $class_level = $_POST['class_level'] ?? '';
    $passing_marks = $_POST['passing_marks'] ?? '';
    $test_date = $_POST['test_date'] ?? '';
    $description = $_POST['description'] ?? '';
    $section = $_POST['section'] ?? '';
    $group_name = $_POST['group_name'] ?? '';
    $image_url = $_POST['image_url'] ?? '';
}

switch ($action) {
    case 'list':
        // Get all test reports with student and test info
        $stmt = $pdo->query("
            SELECT tr.*, s.full_name as student_name, t.test_name, t.subject, t.class_level
            FROM test_reports tr
            LEFT JOIN students s ON tr.student_id = s.id
            LEFT JOIN tests t ON tr.test_id = t.id
            ORDER BY tr.report_date DESC
        ");
        $reports = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($reports);
        break;
    
    case 'add':
        // Add new test report (one test for one student) - logged-in admin only
        require_login();
        if ($student_id && $test_id) {
            $total = (int)$total_marks;
            if ($total <= 0) {
                $check = $pdo->prepare("SELECT total_marks FROM tests WHERE id = ?");
                $check->execute([$test_id]);
                $test = $check->fetch(PDO::FETCH_ASSOC);
                $total = $test ? (int)$test['total_marks'] : 100;
            }
            $marks = min($total, max(0, (int)$marks_obtained));
            $percentage = $total > 0 ? round(($marks / $total) * 100, 2) : 0;
            $grade = grade_for($percentage);
            $report_date = date('Y-m-d H:i:s');

            // Uploading again for the same student+test updates the existing record
            $stmt = $pdo->prepare("INSERT INTO test_reports (student_id, test_id, marks_obtained, total_marks, percentage, grade, remarks, report_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE marks_obtained = VALUES(marks_obtained), total_marks = VALUES(total_marks), percentage = VALUES(percentage), grade = VALUES(grade), remarks = VALUES(remarks), report_date = VALUES(report_date)");
            $stmt->execute([$student_id, $test_id, $marks, $total, $percentage, $grade, $remarks, $report_date]);
            echo json_encode(['success' => true, 'message' => 'Test report added successfully!']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Student and Test are required!']);
        }
        break;

    case 'bulk_add':
        // Save marks for the whole class at once (logged-in admin only)
        require_login();
        $body = file_get_contents('php://input');
        $data = json_decode($body, true) ?: [];
        $test_id = (int)($data['test_id'] ?? 0);
        $reports = $data['reports'] ?? [];

        if ($test_id <= 0 || !is_array($reports) || count($reports) === 0) {
            echo json_encode(['success' => false, 'message' => 'A test and marks for at least one student are required.']);
            break;
        }

        $check = $pdo->prepare("SELECT total_marks FROM tests WHERE id = ?");
        $check->execute([$test_id]);
        $test = $check->fetch(PDO::FETCH_ASSOC);
        if (!$test) {
            echo json_encode(['success' => false, 'message' => 'Test not found.']);
            break;
        }
        $total = (int)$test['total_marks'];

        $stmt = $pdo->prepare("INSERT INTO test_reports (student_id, test_id, marks_obtained, total_marks, percentage, grade, attended, remarks, report_date) VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?) ON DUPLICATE KEY UPDATE marks_obtained = VALUES(marks_obtained), total_marks = VALUES(total_marks), percentage = VALUES(percentage), grade = VALUES(grade), attended = VALUES(attended), remarks = VALUES(remarks), report_date = VALUES(report_date)");

        $report_date = date('Y-m-d H:i:s');
        $saved = 0;
        foreach ($reports as $report) {
            $sid = (int)($report['student_id'] ?? 0);
            if ($sid <= 0) continue;
            $marks = min($total, max(0, (int)($report['marks_obtained'] ?? 0)));
            $percentage = $total > 0 ? round(($marks / $total) * 100, 2) : 0;
            $grade = grade_for($percentage);
            $remarks = isset($report['remarks']) && $report['remarks'] !== '' ? $report['remarks'] : null;
            $stmt->execute([$sid, $test_id, $marks, $total, $percentage, $grade, $remarks, $report_date]);
            $saved++;
        }

        echo json_encode(['success' => true, 'message' => $saved . " students' marks saved.", 'saved' => $saved]);
        break;

    case 'add_test':
        // Define a new test/exam (logged-in admin only)
        require_login();
        $test_name = trim((string)($test_name ?? ''));
        $subject = trim((string)($subject ?? ''));
        $class_level = trim((string)($class_level ?? ''));

        if ($test_name === '' || $subject === '' || $class_level === '') {
            echo json_encode(['success' => false, 'message' => 'Test name, subject and class are required.']);
            break;
        }

        $total = (int)($total_marks > 0 ? $total_marks : 100);
        $pass = (int)($passing_marks > 0 ? $passing_marks : 33);
        $test_date = trim((string)($test_date ?? ''));
        if ($test_date === '') $test_date = null;

        $stmt = $pdo->prepare("INSERT INTO tests (test_name, subject, class_level, section, group_name, image_url, total_marks, passing_marks, test_date, description) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $test_name,
            $subject,
            $class_level,
            trim((string)$section) ?: null,
            trim((string)$group_name) ?: null,
            trim((string)$image_url) ?: null,
            $total,
            $pass,
            $test_date,
            trim((string)($description ?? '')) ?: null
        ]);

        echo json_encode(['success' => true, 'message' => 'Test added. Now upload its marks.', 'id' => $pdo->lastInsertId()]);
        break;
    
    case 'get_students':
        // Get all students for form dropdown
        $stmt = $pdo->query("SELECT * FROM students ORDER BY full_name");
        $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($students);
        break;

    case 'search_students':
        // Search students by name
        $search_term = $_GET['term'] ?? '';
        $like_term = "%$search_term%";
        $stmt = $pdo->prepare("SELECT * FROM students WHERE full_name LIKE ? OR admission_id LIKE ? ORDER BY full_name");
        $stmt->execute([$like_term, $like_term]);
        $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($students);
        break;
    
    case 'get_tests':
        // Get tests for form dropdown (can also filter by section/group with the class)
        $class_level = $_GET['class'] ?? '';
        $filter_section = $_GET['section'] ?? '';
        $filter_group = $_GET['group'] ?? '';

        $sql = "SELECT * FROM tests WHERE (class_level = ? OR class_level = 'All')";
        $params = [$class_level];
        if ($filter_section !== '') {
            $sql .= " AND (section IS NULL OR section = ?)";
            $params[] = $filter_section;
        }
        if ($filter_group !== '') {
            $sql .= " AND (group_name IS NULL OR group_name = ?)";
            $params[] = $filter_group;
        }
        $sql .= " ORDER BY test_date DESC, test_name";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $tests = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($tests);
        break;
    
    case 'get_student':
        // Get student by ID
        $student_id = $_GET['id'] ?? '';
        $stmt = $pdo->prepare("SELECT * FROM students WHERE id = ?");
        $stmt->execute([$student_id]);
        $student = $stmt->fetch(PDO::FETCH_ASSOC);
        echo json_encode($student);
        break;
    
    case 'get_test':
        // Get test by ID
        $test_id = $_GET['id'] ?? '';
        $stmt = $pdo->prepare("SELECT * FROM tests WHERE id = ?");
        $stmt->execute([$test_id]);
        $test = $stmt->fetch(PDO::FETCH_ASSOC);
        echo json_encode($test);
        break;

    case 'student_report':
        // For the website's Test Report page: student's report card by class + roll number
        $class = trim((string)($_GET['class'] ?? ''));
        $roll = trim((string)($_GET['roll'] ?? ''));
        if ($roll === '') {
            echo json_encode(['success' => false, 'message' => 'Roll number is required.']);
            break;
        }

        $sql = "SELECT * FROM students WHERE (roll_no = ? OR admission_id = ?)";
        $params = [$roll, $roll];
        if ($class !== '') {
            $sql .= " AND current_class = ?";
            $params[] = $class;
        }
        $sql .= " ORDER BY id LIMIT 1";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $student = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$student) {
            log_activity('report_not_found', ['class' => $class, 'roll' => $roll], [
                'class_level' => $class,
                'roll_no' => $roll
            ]);
            echo json_encode(['success' => false, 'message' => 'No student with Roll No ' . $roll . ' was found in this class.']);
            break;
        }

        $stmt = $pdo->prepare("
            SELECT tr.id, tr.marks_obtained, tr.total_marks, tr.percentage, tr.grade,
                   tr.attended, tr.remarks, tr.report_date,
                   t.test_name, t.subject, t.passing_marks, t.test_date, t.image_url, t.section, t.group_name
            FROM test_reports tr
            INNER JOIN tests t ON tr.test_id = t.id
            WHERE tr.student_id = ?
            ORDER BY t.test_date, t.test_name, t.subject
        ");
        $stmt->execute([$student['id']]);
        $reports = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $obtained = 0;
        $total = 0;
        $exam_names = [];
        $images = [];
        foreach ($reports as $report) {
            $obtained += (int)$report['marks_obtained'];
            $total += (int)$report['total_marks'];
            if ($report['test_name'] !== '' && !in_array($report['test_name'], $exam_names, true)) {
                $exam_names[] = $report['test_name'];
            }
            $img = $report['image_url'] ?? '';
            if ($img !== '' && !in_array($img, $images, true)) {
                $images[] = $img;
            }
        }
        $percentage = $total > 0 ? round($obtained / $total * 100, 2) : 0;

        log_activity('report_viewed', [
            'student' => $student['full_name'],
            'class' => $class,
            'roll' => $roll,
            'percentage' => $percentage
        ], [
            'student_id' => $student['id'],
            'student_name' => $student['full_name'],
            'class_level' => $student['current_class'],
            'roll_no' => $student['roll_no']
        ]);

        echo json_encode([
            'success' => true,
            'student' => $student,
            'reports' => $reports,
            'report_images' => $images,
            'exam_names' => $exam_names,
            'summary' => [
                'obtained' => $obtained,
                'total' => $total,
                'percentage' => $percentage,
                'grade' => grade_for($percentage),
                'result' => $percentage >= 40 ? 'PASS' : 'FAIL'
            ]
        ]);
        break;

    default:
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
}