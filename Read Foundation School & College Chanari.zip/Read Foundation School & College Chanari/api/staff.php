<?php
require 'config.php';

header('Content-Type: application/json');

$stmt = $pdo->query("SELECT s.*, u.full_name as user_name FROM staff s LEFT JOIN users u ON s.user_id = u.id WHERE s.status = 'active'");
$staff = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($staff);