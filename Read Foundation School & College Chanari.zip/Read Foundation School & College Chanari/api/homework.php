<?php
// api/homework.php - Homework & Test papers
//   GET  ?action=list[&class=5]   -> public list (website)
//   POST ?action=add              -> admin only (add homework / test)
//   POST ?action=delete           -> admin only

require 'config.php';

header('Content-Type: application/json');

$CLASSES = ['Nursery', 'KG', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'];

// Create the table automatically so the admin panel starts working without
// importing the SQL file manually.
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS homework (
        id INT AUTO_INCREMENT PRIMARY KEY,
        type ENUM('test', 'homework') NOT NULL DEFAULT 'homework',
        class_level VARCHAR(50) NOT NULL,
        subject VARCHAR(80) NOT NULL,
        title VARCHAR(150) NOT NULL,
        description TEXT,
        assigned_date DATE NULL,
        due_date DATE NULL,
        file_url VARCHAR(255) NULL,
        created_by INT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        KEY idx_hw_class (class_level),
        KEY idx_hw_assigned (assigned_date)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
} catch (\Throwable $e) {
    echo json_encode(['success' => false, 'message' => 'Homework table could not be created: ' . $e->getMessage()]);
    exit;
}

function clean_date($value) {
    $value = trim((string)$value);
    if ($value === '') return null;
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) return null;
    $d = DateTime::createFromFormat('Y-m-d', $value);
    return ($d && $d->format('Y-m-d') === $value) ? $value : null;
}

$action = $_GET['action'] ?? 'list';

switch ($action) {

    case 'list':
        $class = trim((string)($_GET['class'] ?? ''));
        if ($class !== '' && in_array($class, $CLASSES, true)) {
            $stmt = $pdo->prepare("SELECT * FROM homework WHERE class_level = ? ORDER BY COALESCE(assigned_date, DATE(created_at)) DESC, id DESC");
            $stmt->execute([$class]);
        } else {
            $stmt = $pdo->query("SELECT * FROM homework ORDER BY COALESCE(assigned_date, DATE(created_at)) DESC, id DESC");
        }
        echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
        break;

    case 'add':
        require_login();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['success' => false, 'message' => 'Please send the homework via POST.']);
            break;
        }

        $type = ($_POST['type'] ?? '') === 'test' ? 'test' : 'homework';
        $class = trim((string)($_POST['class_level'] ?? ''));
        $subject = trim((string)($_POST['subject'] ?? ''));
        $title = trim((string)($_POST['title'] ?? ''));
        $description = trim((string)($_POST['description'] ?? ''));
        $assigned = clean_date($_POST['assigned_date'] ?? '');
        $due = clean_date($_POST['due_date'] ?? '');

        if (!in_array($class, $CLASSES, true)) {
            echo json_encode(['success' => false, 'message' => 'Please select a valid class.']);
            break;
        }
        if ($subject === '' || $title === '') {
            echo json_encode(['success' => false, 'message' => 'Subject and title are required.']);
            break;
        }

        // Only files uploaded to uploads/homework by our own upload API are accepted.
        $fileUrl = trim((string)($_POST['file_url'] ?? ''));
        if ($fileUrl !== '' && !preg_match('#^uploads/homework/[A-Za-z0-9._-]+\.pdf$#i', $fileUrl)) {
            $fileUrl = '';
        }

        $stmt = $pdo->prepare("INSERT INTO homework
            (type, class_level, subject, title, description, assigned_date, due_date, file_url, created_by)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $type,
            $class,
            mb_substr($subject, 0, 80),
            mb_substr($title, 0, 150),
            $description !== '' ? $description : null,
            $assigned,
            $due,
            $fileUrl !== '' ? $fileUrl : null,
            admin_user_id()
        ]);

        echo json_encode([
            'success' => true,
            'message' => 'Homework saved. It is now visible on the Homework page.',
            'id' => (int)$pdo->lastInsertId()
        ]);
        break;

    case 'delete':
        require_login();
        $id = (int)($_POST['id'] ?? $_GET['id'] ?? 0);
        if ($id <= 0) {
            echo json_encode(['success' => false, 'message' => 'Invalid homework ID.']);
            break;
        }

        $stmt = $pdo->prepare("SELECT file_url FROM homework WHERE id = ?");
        $stmt->execute([$id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$row) {
            echo json_encode(['success' => false, 'message' => 'Homework not found.']);
            break;
        }

        $stmt = $pdo->prepare("DELETE FROM homework WHERE id = ?");
        $stmt->execute([$id]);

        // Remove the uploaded PDF as well (only inside uploads/homework).
        if (!empty($row['file_url']) && preg_match('#^uploads/homework/[A-Za-z0-9._-]+\.pdf$#i', $row['file_url'])) {
            $path = dirname(__DIR__) . '/' . $row['file_url'];
            if (is_file($path)) @unlink($path);
        }

        echo json_encode(['success' => true, 'message' => 'Homework deleted.']);
        break;

    default:
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
}
