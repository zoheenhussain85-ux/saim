<?php
require 'config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = $_POST['full_name'] ?? '';
    $email = $_POST['email'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $current_class = $_POST['current_class'] ?? '';
    $applying_for_class = $_POST['applying_for_class'] ?? '';
    $dob = $_POST['dob'] ?? '';
    $gender = $_POST['gender'] ?? '';
    $address = $_POST['address'] ?? '';
    $parent_name = $_POST['parent_name'] ?? '';
    $previous_school = $_POST['previous_school'] ?? '';
    $comments = $_POST['comments'] ?? '';
    
    $ip_address = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    
    $stmt = $pdo->prepare("INSERT INTO admission_inquiries (full_name, email, phone, current_class, applying_for_class, date_of_birth, gender, address, parent_name, previous_school, comments, ip_address) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$full_name, $email, $phone, $current_class, $applying_for_class, $dob, $gender, $address, $parent_name, $previous_school, $comments, $ip_address]);

    log_activity('admission_submitted', [
        'name' => $full_name,
        'applying_for' => $applying_for_class,
        'parent' => $parent_name
    ], [
        'student_name' => $full_name,
        'class_level' => $applying_for_class
    ]);

    echo json_encode(['success' => true, 'message' => 'Admission inquiry submitted successfully! Our admissions team will contact you soon.']);
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}