<?php
require 'config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $message = $_POST['message'] ?? '';
    
    $stmt = $pdo->prepare("INSERT INTO admission_inquiries (full_name, email, comments) VALUES (?, ?, ?)");
    $stmt->execute([$name, $email, $message]);

    log_activity('contact_message', ['name' => $name, 'email' => $email], ['student_name' => $name]);

    echo json_encode(['success' => true, 'message' => 'Thank you for your message! We will get back to you soon.']);
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}