<?php
require 'config.php';

header('Content-Type: application/json');

$stmt = $pdo->query("SELECT e.*, u.full_name as created_by_name FROM events e LEFT JOIN users u ON e.created_by = u.id WHERE e.status = 'upcoming' ORDER BY e.event_date ASC");
$events = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($events);