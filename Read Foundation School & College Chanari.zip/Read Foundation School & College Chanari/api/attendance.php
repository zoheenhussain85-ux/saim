<?php
require 'config.php';

header('Content-Type: application/json');

$action = $_GET['action'] ?? 'list';

function valid_date($value) {
    $dt = DateTime::createFromFormat('Y-m-d', (string)$value);
    return $dt && $dt->format('Y-m-d') === (string)$value;
}

function request_json() {
    $body = file_get_contents('php://input');
    return json_decode($body, true) ?: [];
}

switch ($action) {
    case 'list':
        // Attendance for one class on one date
        $class = $_GET['class'] ?? '';
        $date = $_GET['date'] ?? '';
        if ($class === '' || !valid_date($date)) {
            echo json_encode(['success' => false, 'message' => 'A class and a valid date are required.']);
            break;
        }
        $stmt = $pdo->prepare("
            SELECT a.id, a.student_id, a.att_date, a.status, a.remarks,
                   s.full_name, s.roll_no, s.admission_id
            FROM attendance a
            INNER JOIN students s ON a.student_id = s.id
            WHERE s.current_class = ? AND a.att_date = ?
            ORDER BY (s.roll_no+0), s.full_name
        ");
        $stmt->execute([$class, $date]);
        log_activity('attendance_list_viewed', ['class' => $class, 'date' => $date], ['class_level' => $class]);
        echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
        break;

    case 'save':
        // Save attendance for the whole class at once (logged-in admin only)
        require_login();
        $data = request_json();
        $date = $data['date'] ?? '';
        $records = $data['records'] ?? [];

        if (!valid_date($date)) {
            echo json_encode(['success' => false, 'message' => 'Invalid date (format: YYYY-MM-DD).']);
            break;
        }
        if (!is_array($records) || count($records) === 0) {
            echo json_encode(['success' => false, 'message' => 'No student selected.']);
            break;
        }

        $allowed = ['present', 'absent', 'late', 'leave'];
        $stmt = $pdo->prepare("INSERT INTO attendance (student_id, att_date, status, remarks) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE status = VALUES(status), remarks = VALUES(remarks)");

        $saved = 0;
        foreach ($records as $record) {
            $student_id = (int)($record['student_id'] ?? 0);
            $status = $record['status'] ?? 'present';
            if ($student_id <= 0 || !in_array($status, $allowed, true)) continue;
            $remarks = isset($record['remarks']) && $record['remarks'] !== '' ? $record['remarks'] : null;
            $stmt->execute([$student_id, $date, $status, $remarks]);
            $saved++;
        }

        echo json_encode(['success' => true, 'message' => $saved . " students' attendance saved.", 'saved' => $saved]);
        log_activity('attendance_saved', ['date' => $date, 'saved' => $saved], ['class_level' => $data['class'] ?? '']);
        break;

    case 'summary':
        // Class attendance report for a date range (present/absent/late/leave + %)
        $class = $_GET['class'] ?? '';
        $from = $_GET['from'] ?? '';
        $to = $_GET['to'] ?? '';
        if ($class === '' || !valid_date($from) || !valid_date($to)) {
            echo json_encode(['success' => false, 'message' => 'A class and valid from/to dates are required.']);
            break;
        }

        $stmt = $pdo->prepare("
            SELECT s.id, s.full_name, s.roll_no, s.admission_id,
                   COALESCE(SUM(a.status = 'present'), 0) AS present_days,
                   COALESCE(SUM(a.status = 'absent'), 0) AS absent_days,
                   COALESCE(SUM(a.status = 'late'), 0) AS late_days,
                   COALESCE(SUM(a.status = 'leave'), 0) AS leave_days,
                   COUNT(a.id) AS total_days,
                   ROUND((COALESCE(SUM(a.status = 'present'), 0) + COALESCE(SUM(a.status = 'late'), 0)) / NULLIF(COUNT(a.id), 0) * 100, 1) AS percentage
            FROM students s
            LEFT JOIN attendance a ON a.student_id = s.id AND a.att_date BETWEEN ? AND ?
            WHERE s.current_class = ?
            GROUP BY s.id, s.full_name, s.roll_no, s.admission_id
            ORDER BY (s.roll_no+0), s.full_name
        ");
        $stmt->execute([$from, $to, $class]);
        log_activity('attendance_report_viewed', ['class' => $class, 'from' => $from, 'to' => $to], ['class_level' => $class]);
        echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
        break;

    case 'date_report':
        // Attendance for all classes on one date (for the website's date-wise report)
        $date = $_GET['date'] ?? '';
        if (!valid_date($date)) {
            echo json_encode(['success' => false, 'message' => 'A valid date is required (format: YYYY-MM-DD).']);
            break;
        }

        $stmt = $pdo->prepare("
            SELECT s.id AS student_id, s.full_name, s.parent_name, s.roll_no, s.admission_id,
                   s.current_class, a.status
            FROM students s
            LEFT JOIN attendance a ON a.student_id = s.id AND a.att_date = ?
            ORDER BY s.current_class, (s.roll_no+0), s.full_name
        ");
        $stmt->execute([$date]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $byClass = [];
        foreach ($rows as $row) {
            $cls = $row['current_class'];
            if (!isset($byClass[$cls])) {
                $byClass[$cls] = ['current_class' => $cls, 'total' => 0, 'present' => 0, 'absent' => 0, 'late' => 0, 'leave' => 0, 'unmarked' => 0, 'marked' => 0, 'percentage' => 0];
            }
            $byClass[$cls]['total']++;
            $status = $row['status'] ?? '';
            if ($status === '') {
                $byClass[$cls]['unmarked']++;
            } else {
                $byClass[$cls]['marked']++;
                if (isset($byClass[$cls][$status])) $byClass[$cls][$status]++;
            }
        }
        foreach ($byClass as &$clsRow) {
            $clsRow['percentage'] = $clsRow['marked'] > 0
                ? round(($clsRow['present'] + $clsRow['late']) / $clsRow['marked'] * 100, 1)
                : 0;
        }
        unset($clsRow);
        ksort($byClass, SORT_NATURAL);

        log_activity('attendance_viewed', ['date' => $date, 'classes' => count($byClass)]);

        echo json_encode([
            'success' => true,
            'date' => $date,
            'classes' => array_values($byClass),
            'students' => $rows
        ]);
        break;

    default:
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
}
