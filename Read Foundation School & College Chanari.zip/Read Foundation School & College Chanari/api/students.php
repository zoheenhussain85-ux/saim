<?php
require 'config.php';

header('Content-Type: application/json');

$action = $_GET['action'] ?? 'list';

function request_data() {
    $contentType = $_SERVER['CONTENT_TYPE'] ?? '';
    if (strpos($contentType, 'application/json') !== false) {
        $body = file_get_contents('php://input');
        return json_decode($body, true) ?: [];
    }
    return $_POST;
}

function clean($value) {
    return trim((string)$value);
}

function grade_for_percentage($percentage) {
    if ($percentage >= 80) return 'A+';
    if ($percentage >= 70) return 'A';
    if ($percentage >= 60) return 'B';
    if ($percentage >= 50) return 'C';
    if ($percentage >= 40) return 'D';
    return 'F';
}

switch ($action) {
    case 'list':
        // All students (or students in one class) - for dropdowns and lists
        $class = $_GET['class'] ?? '';
        if ($class !== '') {
            $stmt = $pdo->prepare("SELECT * FROM students WHERE current_class = ? ORDER BY (roll_no+0), full_name");
            $stmt->execute([$class]);
        } else {
            $stmt = $pdo->query("SELECT * FROM students ORDER BY current_class, (roll_no+0), full_name");
        }
        log_activity('students_list_viewed', ['class' => $class], ['class_level' => $class]);
        echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
        break;

    case 'add':
        // Add a new student (logged-in admin only)
        require_login();
        $data = request_data();
        $admission_id = clean($data['admission_id'] ?? '');
        $full_name = clean($data['full_name'] ?? '');
        $current_class = clean($data['current_class'] ?? '');

        if ($full_name === '' || $current_class === '') {
            echo json_encode(['success' => false, 'message' => 'Student name and class are both required.']);
            break;
        }

        // Generate an Admission ID automatically if left blank: FS2026-001
        if ($admission_id === '') {
            $prefix = 'FS' . date('Y') . '-';
            $number = 1;
            do {
                $admission_id = $prefix . str_pad((string)$number, 3, '0', STR_PAD_LEFT);
                $check = $pdo->prepare("SELECT COUNT(*) AS c FROM students WHERE admission_id = ?");
                $check->execute([$admission_id]);
                $number++;
            } while ($check->fetch()['c'] > 0 && $number < 1000);
        } else {
            $check = $pdo->prepare("SELECT COUNT(*) AS c FROM students WHERE admission_id = ?");
            $check->execute([$admission_id]);
            if ($check->fetch()['c'] > 0) {
                echo json_encode(['success' => false, 'message' => 'This Admission ID already exists.']);
                break;
            }
        }

        $gender = in_array($data['gender'] ?? '', ['male', 'female', 'other'], true) ? $data['gender'] : 'male';
        $date_of_birth = clean($data['date_of_birth'] ?? '');
        if ($date_of_birth === '') $date_of_birth = null;

        // Photo must be an image from the uploads folder only
        $image_url = clean($data['image_url'] ?? '');
        if ($image_url !== '' && !preg_match('#^uploads/[A-Za-z0-9._-]+\.(jpe?g|png|gif|webp)$#i', $image_url)) {
            $image_url = '';
        }

        $stmt = $pdo->prepare("INSERT INTO students (admission_id, full_name, date_of_birth, gender, current_class, section, student_group, roll_no, parent_name, email, phone, address, blood_group, image_url) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $admission_id,
            $full_name,
            $date_of_birth,
            $gender,
            $current_class,
            clean($data['section'] ?? '') ?: null,
            clean($data['student_group'] ?? '') ?: null,
            clean($data['roll_no'] ?? '') ?: null,
            clean($data['parent_name'] ?? '') ?: null,
            clean($data['email'] ?? '') ?: null,
            clean($data['phone'] ?? '') ?: null,
            clean($data['address'] ?? '') ?: null,
            clean($data['blood_group'] ?? '') ?: null,
            $image_url !== '' ? $image_url : null
        ]);

        echo json_encode([
            'success' => true,
            'message' => 'Student added. Admission ID: ' . $admission_id,
            'id' => $pdo->lastInsertId(),
            'admission_id' => $admission_id
        ]);
        log_activity('student_added', ['student' => $full_name, 'admission_id' => $admission_id], [
            'student_id' => $pdo->lastInsertId(),
            'student_name' => $full_name,
            'class_level' => $current_class,
            'roll_no' => $data['roll_no'] ?? ''
        ]);
        break;

    case 'get':
        // Details of a single student
        $id = $_GET['id'] ?? '';
        $stmt = $pdo->prepare("SELECT * FROM students WHERE id = ?");
        $stmt->execute([$id]);
        $student = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($student) {
            log_activity('student_viewed', ['student' => $student['full_name']], [
                'student_id' => $student['id'],
                'student_name' => $student['full_name'],
                'class_level' => $student['current_class'],
                'roll_no' => $student['roll_no']
            ]);
            echo json_encode($student);
        } else {
            echo json_encode(['success' => false, 'message' => 'Student not found.']);
        }
        break;

    case 'profile':
        // One student's test reports + attendance + overall summary for the last 1 month
        $id = (int)($_GET['id'] ?? 0);
        if ($id <= 0) {
            echo json_encode(['success' => false, 'message' => 'No student selected.']);
            break;
        }

        $stmt = $pdo->prepare("SELECT * FROM students WHERE id = ?");
        $stmt->execute([$id]);
        $student = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$student) {
            echo json_encode(['success' => false, 'message' => 'Student not found.']);
            break;
        }

        $from = date('Y-m-d', strtotime('-1 month'));
        $to = date('Y-m-d');

        // Test reports from the last 1 month (test date, otherwise report date)
        $stmt = $pdo->prepare("
            SELECT tr.marks_obtained, tr.total_marks, tr.percentage, tr.grade,
                   tr.attended, tr.remarks, tr.report_date,
                   t.test_name, t.subject, t.test_date
            FROM test_reports tr
            INNER JOIN tests t ON tr.test_id = t.id
            WHERE tr.student_id = ?
              AND DATE(COALESCE(t.test_date, tr.report_date)) BETWEEN ? AND ?
            ORDER BY DATE(COALESCE(t.test_date, tr.report_date)) DESC, t.test_name, t.subject
        ");
        $stmt->execute([$id, $from, $to]);
        $tests = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $obtained = 0;
        $total = 0;
        foreach ($tests as $test) {
            $obtained += (int)$test['marks_obtained'];
            $total += (int)$test['total_marks'];
        }
        $test_percentage = $total > 0 ? round($obtained / $total * 100, 2) : 0;

        // Daily attendance for the last 1 month
        $stmt = $pdo->prepare("
            SELECT att_date, status, remarks
            FROM attendance
            WHERE student_id = ? AND att_date BETWEEN ? AND ?
            ORDER BY att_date DESC
        ");
        $stmt->execute([$id, $from, $to]);
        $attendance = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $counts = ['present' => 0, 'absent' => 0, 'late' => 0, 'leave' => 0];
        foreach ($attendance as $row) {
            if (isset($counts[$row['status']])) $counts[$row['status']]++;
        }
        $marked = array_sum($counts);
        $attendance_percentage = $marked > 0
            ? round(($counts['present'] + $counts['late']) / $marked * 100, 1)
            : 0;

        // Overall (full history) summary
        $stmt = $pdo->prepare("SELECT COUNT(*) AS tests, COALESCE(SUM(marks_obtained),0) AS obtained, COALESCE(SUM(total_marks),0) AS total FROM test_reports WHERE student_id = ?");
        $stmt->execute([$id]);
        $overall_tests = $stmt->fetch(PDO::FETCH_ASSOC);
        $overall_test_percentage = (int)$overall_tests['total'] > 0
            ? round((int)$overall_tests['obtained'] / (int)$overall_tests['total'] * 100, 2)
            : 0;

        $stmt = $pdo->prepare("
            SELECT COUNT(*) AS total_days,
                   COALESCE(SUM(status = 'present'), 0) AS present_days,
                   COALESCE(SUM(status = 'late'), 0) AS late_days
            FROM attendance WHERE student_id = ?
        ");
        $stmt->execute([$id]);
        $overall_attendance = $stmt->fetch(PDO::FETCH_ASSOC);
        $overall_attendance_percentage = (int)$overall_attendance['total_days'] > 0
            ? round(((int)$overall_attendance['present_days'] + (int)$overall_attendance['late_days']) / (int)$overall_attendance['total_days'] * 100, 1)
            : 0;

        log_activity('student_profile_viewed', ['student' => $student['full_name']], [
            'student_id' => $id,
            'student_name' => $student['full_name'],
            'class_level' => $student['current_class'],
            'roll_no' => $student['roll_no']
        ]);

        echo json_encode([
            'success' => true,
            'student' => $student,
            'range' => ['from' => $from, 'to' => $to],
            'tests' => $tests,
            'tests_summary' => [
                'count' => count($tests),
                'obtained' => $obtained,
                'total' => $total,
                'percentage' => $test_percentage,
                'grade' => grade_for_percentage($test_percentage)
            ],
            'attendance' => $attendance,
            'attendance_summary' => [
                'present' => $counts['present'],
                'absent' => $counts['absent'],
                'late' => $counts['late'],
                'leave' => $counts['leave'],
                'total' => $marked,
                'percentage' => $attendance_percentage
            ],
            'overall' => [
                'tests' => (int)$overall_tests['tests'],
                'test_percentage' => $overall_test_percentage,
                'attendance_days' => (int)$overall_attendance['total_days'],
                'attendance_percentage' => $overall_attendance_percentage
            ]
        ]);
        break;

    case 'update_photo':
        // Add / replace a student's photo (logged-in admin only)
        require_login();
        $data = request_data();
        $id = (int)($data['id'] ?? 0);
        $image_url = clean($data['image_url'] ?? '');

        if ($id <= 0) {
            echo json_encode(['success' => false, 'message' => 'No student selected.']);
            break;
        }
        if (!preg_match('#^uploads/[A-Za-z0-9._-]+\.(jpe?g|png|gif|webp)$#i', $image_url)) {
            echo json_encode(['success' => false, 'message' => 'Invalid photo URL. Please upload again.']);
            break;
        }

        $check = $pdo->prepare("SELECT full_name, current_class FROM students WHERE id = ?");
        $check->execute([$id]);
        $student = $check->fetch(PDO::FETCH_ASSOC);
        if (!$student) {
            echo json_encode(['success' => false, 'message' => 'Student not found.']);
            break;
        }

        $stmt = $pdo->prepare("UPDATE students SET image_url = ? WHERE id = ?");
        $stmt->execute([$image_url, $id]);

        log_activity('student_photo_updated', ['student' => $student['full_name'], 'image_url' => $image_url], [
            'student_id' => $id,
            'student_name' => $student['full_name'],
            'class_level' => $student['current_class']
        ]);

        echo json_encode(['success' => true, 'message' => 'Student photo saved.', 'image_url' => $image_url]);
        break;

    default:
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
}
