<?php
// activity.php - View what happened on the website (activity log)
// BACKEND ONLY: no page/tab was built in the frontend. Admin login required.
//
// How to use (type the URL directly in the browser):
//   api/activity.php?action=summary                     -> today / last 7 days summary
//   api/activity.php?action=list&limit=200              -> last 200 activity rows
//   api/activity.php?action=list&roll=1&class=11        -> activity for one roll number
//   api/activity.php?action=list&from=2026-10-01&to=2026-10-15
//   api/activity.php?action=list&action_name=report_viewed  (see action=...)
//   api/activity.php?action=student&roll=1              -> full history of a student
//   api/activity.php?action=student&ip=127.0.0.1        -> full history of a visitor
//   api/activity.php?action=actions                     -> list of all actions
//   api/activity.php?action=purge&days=180              -> delete old rows
require 'config.php';

header('Content-Type: application/json');

require_login();

$action = $_GET['action'] ?? 'list';

function act_valid_date($value) {
    $dt = DateTime::createFromFormat('Y-m-d', (string)$value);
    return $dt && $dt->format('Y-m-d') === (string)$value;
}

function act_date_range(&$from, &$to) {
    if (!act_valid_date($from)) $from = date('Y-m-d', strtotime('-7 days'));
    if (!act_valid_date($to)) $to = date('Y-m-d');
    if ($from > $to) { $t = $from; $from = $to; $to = $t; }
}

function act_limit($default = 100, $max = 500) {
    $limit = (int)($_GET['limit'] ?? $default);
    if ($limit <= 0) $limit = $default;
    if ($limit > $max) $limit = $max;
    return $limit;
}

function act_query_filters(&$params) {
    $params = [];
    $sql = " WHERE 1=1";

    $from = $_GET['from'] ?? '';
    $to = $_GET['to'] ?? '';
    if (act_valid_date($from)) { $sql .= " AND created_at >= ?"; $params[] = $from . ' 00:00:00'; }
    if (act_valid_date($to)) { $sql .= " AND created_at <= ?"; $params[] = $to . ' 23:59:59'; }

    if (($_GET['action_name'] ?? '') !== '') {
        $sql .= " AND action = ?";
        $params[] = trim((string)$_GET['action_name']);
    }
    if (in_array($_GET['actor'] ?? '', ['guest', 'admin'], true)) {
        $sql .= " AND actor_type = ?";
        $params[] = $_GET['actor'];
    }
    if (($_GET['class'] ?? '') !== '') {
        $sql .= " AND class_level = ?";
        $params[] = trim((string)$_GET['class']);
    }
    if (($_GET['roll'] ?? '') !== '') {
        $sql .= " AND roll_no = ?";
        $params[] = trim((string)$_GET['roll']);
    }
    if ((int)($_GET['student_id'] ?? 0) > 0) {
        $sql .= " AND student_id = ?";
        $params[] = (int)$_GET['student_id'];
    }
    if (($_GET['ip'] ?? '') !== '') {
        $sql .= " AND ip_address = ?";
        $params[] = trim((string)$_GET['ip']);
    }
    if (($_GET['q'] ?? '') !== '') {
        $sql .= " AND (student_name LIKE ? OR detail LIKE ? OR ip_address LIKE ? OR roll_no LIKE ?)";
        $like = '%' . trim((string)$_GET['q']) . '%';
        array_push($params, $like, $like, $like, $like);
    }
    return $sql;
}

switch ($action) {
    case 'actions':
        // For the filter dropdown: which actions are being recorded
        $stmt = $pdo->query("
            SELECT action, COUNT(*) AS hits, MAX(created_at) AS last_at
            FROM activity_log
            GROUP BY action
            ORDER BY hits DESC, action
        ");
        echo json_encode(['success' => true, 'actions' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
        break;

    case 'list':
        // Raw activity list (with filters)
        $where = act_query_filters($params);
        $limit = act_limit(100, 500);
        $offset = max(0, (int)($_GET['offset'] ?? 0));

        $stmt = $pdo->prepare("SELECT COUNT(*) AS total FROM activity_log" . $where);
        $stmt->execute($params);
        $total = (int)$stmt->fetch(PDO::FETCH_ASSOC)['total'];

        $stmt = $pdo->prepare("
            SELECT id, created_at, actor_type, admin_user_id, student_id, student_name,
                   class_level, roll_no, action, page, detail, ip_address, user_agent
            FROM activity_log" . $where . "
            ORDER BY id DESC
            LIMIT $limit OFFSET $offset
        ");
        $stmt->execute($params);

        echo json_encode([
            'success' => true,
            'total' => $total,
            'limit' => $limit,
            'offset' => $offset,
            'rows' => $stmt->fetchAll(PDO::FETCH_ASSOC)
        ]);
        break;

    case 'summary':
        // Date range summary: who did what
        $from = $_GET['from'] ?? '';
        $to = $_GET['to'] ?? '';
        act_date_range($from, $to);

        $stmt = $pdo->prepare("
            SELECT COUNT(*) AS total,
                   COUNT(DISTINCT ip_address) AS visitors,
                   SUM(actor_type = 'admin') AS admin_hits,
                   SUM(actor_type = 'guest') AS guest_hits
            FROM activity_log
            WHERE created_at BETWEEN ? AND ?
        ");
        $stmt->execute([$from . ' 00:00:00', $to . ' 23:59:59']);
        $totals = $stmt->fetch(PDO::FETCH_ASSOC);

        $stmt = $pdo->prepare("
            SELECT action, COUNT(*) AS hits, MAX(created_at) AS last_at
            FROM activity_log
            WHERE created_at BETWEEN ? AND ?
            GROUP BY action
            ORDER BY hits DESC, action
        ");
        $stmt->execute([$from . ' 00:00:00', $to . ' 23:59:59']);
        $byAction = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // What a student viewed on the website (roll/class rows)
        $stmt = $pdo->prepare("
            SELECT COALESCE(student_id, 0) AS student_id,
                   MAX(student_name) AS student_name,
                   MAX(class_level) AS class_level,
                   roll_no,
                   COUNT(*) AS hits,
                   COUNT(DISTINCT action) AS different_actions,
                   GROUP_CONCAT(DISTINCT action ORDER BY action SEPARATOR ', ') AS actions,
                   MAX(created_at) AS last_at
            FROM activity_log
            WHERE created_at BETWEEN ? AND ? AND roll_no IS NOT NULL AND roll_no <> ''
            GROUP BY COALESCE(student_id, 0), roll_no
            ORDER BY hits DESC, last_at DESC
        ");
        $stmt->execute([$from . ' 00:00:00', $to . ' 23:59:59']);
        $byStudent = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // By visitor (IP): how many times each device visited
        $stmt = $pdo->prepare("
            SELECT ip_address,
                   COUNT(*) AS hits,
                   COUNT(DISTINCT action) AS different_actions,
                   GROUP_CONCAT(DISTINCT action ORDER BY action SEPARATOR ', ') AS actions,
                   MAX(student_name) AS last_student,
                   MAX(created_at) AS last_at
            FROM activity_log
            WHERE created_at BETWEEN ? AND ?
            GROUP BY ip_address
            ORDER BY hits DESC, last_at DESC
            LIMIT 100
        ");
        $stmt->execute([$from . ' 00:00:00', $to . ' 23:59:59']);
        $byVisitor = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $stmt = $pdo->prepare("
            SELECT DATE(created_at) AS day, COUNT(*) AS hits
            FROM activity_log
            WHERE created_at BETWEEN ? AND ?
            GROUP BY DATE(created_at)
            ORDER BY day
        ");
        $stmt->execute([$from . ' 00:00:00', $to . ' 23:59:59']);
        $byDay = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode([
            'success' => true,
            'from' => $from,
            'to' => $to,
            'totals' => $totals,
            'actions' => $byAction,
            'students' => $byStudent,
            'visitors' => $byVisitor,
            'days' => $byDay
        ]);
        break;

    case 'student':
        // Full history of one student / visitor
        $where = " WHERE 1=1";
        $params = [];
        $identity = [];

        $student_id = (int)($_GET['student_id'] ?? 0);
        $roll = trim((string)($_GET['roll'] ?? ''));
        $admission = trim((string)($_GET['admission_id'] ?? ''));
        $ip = trim((string)($_GET['ip'] ?? ''));
        $class = trim((string)($_GET['class'] ?? ''));

        if ($admission !== '') {
            $stmt = $pdo->prepare("SELECT id, full_name, current_class, roll_no FROM students WHERE admission_id = ? LIMIT 1");
            $stmt->execute([$admission]);
            $st = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($st) {
                $student_id = (int)$st['id'];
                if ($roll === '') $roll = (string)$st['roll_no'];
                if ($class === '') $class = (string)$st['current_class'];
                $identity['student'] = $st;
            }
        }

        if ($student_id > 0) {
            $where .= " AND student_id = ?";
            $params[] = $student_id;
        }
        if ($roll !== '') {
            $where .= " AND roll_no = ?";
            $params[] = $roll;
        }
        if ($class !== '') {
            $where .= " AND class_level = ?";
            $params[] = $class;
        }
        if ($ip !== '') {
            $where .= " AND ip_address = ?";
            $params[] = $ip;
        }
        if (count($params) === 0) {
            echo json_encode(['success' => false, 'message' => 'One of roll, admission_id, student_id or ip is required.']);
            break;
        }

        if (!isset($identity['student']) && ($roll !== '' || $student_id > 0)) {
            $sql = "SELECT id, full_name, current_class, roll_no, admission_id FROM students WHERE ";
            $conds = [];
            $p = [];
            if ($roll !== '') { $conds[] = "roll_no = ?"; $p[] = $roll; }
            if ($student_id > 0) { $conds[] = "id = ?"; $p[] = $student_id; }
            if ($class !== '') { $conds[] = "current_class = ?"; $p[] = $class; }
            $sql .= implode(' AND ', $conds) . " LIMIT 1";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($p);
            $st = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($st) $identity['student'] = $st;
        }

        $stmt = $pdo->prepare("
            SELECT id, created_at, actor_type, student_name, class_level, roll_no,
                   action, page, detail, ip_address, user_agent
            FROM activity_log" . $where . "
            ORDER BY id DESC
            LIMIT 300
        ");
        $stmt->execute($params);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $byAction = [];
        $ips = [];
        foreach ($rows as $row) {
            $byAction[$row['action']] = ($byAction[$row['action']] ?? 0) + 1;
            $ips[$row['ip_address']] = true;
        }

        echo json_encode([
            'success' => true,
            'identity' => $identity,
            'total_actions' => count($rows),
            'by_action' => $byAction,
            'ips' => array_keys($ips),
            'first_at' => $rows ? $rows[count($rows) - 1]['created_at'] : null,
            'last_at' => $rows ? $rows[0]['created_at'] : null,
            'rows' => $rows
        ]);
        break;

    case 'purge':
        // Delete old activity rows (default: 180 days)
        $days = (int)($_GET['days'] ?? 180);
        if ($days < 1) $days = 1;
        $stmt = $pdo->prepare("DELETE FROM activity_log WHERE created_at < NOW() - INTERVAL ? DAY");
        $stmt->execute([$days]);
        echo json_encode(['success' => true, 'message' => $stmt->rowCount() . ' rows older than ' . $days . ' days deleted.']);
        break;

    default:
        echo json_encode(['success' => false, 'message' => 'Invalid action. Valid: list, summary, student, actions, purge']);
}
