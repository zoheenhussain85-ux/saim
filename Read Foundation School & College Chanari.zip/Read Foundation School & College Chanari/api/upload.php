<?php
require 'config.php';

header('Content-Type: application/json');

$action = $_GET['action'] ?? 'upload';

switch ($action) {
    case 'upload':
        // Image upload (logged-in admin only)
        require_login();
        // Send the POST file field named "image" (jpg/png/gif/webp), max 5MB
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['success' => false, 'message' => 'Please send the image via POST.']);
            break;
        }
        if (!isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
            echo json_encode(['success' => false, 'message' => 'No image was selected (or the upload failed).']);
            break;
        }

        $file = $_FILES['image'];
        $maxBytes = 5 * 1024 * 1024;
        if ($file['size'] > $maxBytes) {
            echo json_encode(['success' => false, 'message' => 'The image is larger than 5MB. Please upload a smaller image.']);
            break;
        }

        // Real image files only (both name and content are checked)
        $info = @getimagesize($file['tmp_name']);
        $allowed = [IMAGETYPE_JPEG, IMAGETYPE_PNG, IMAGETYPE_GIF, IMAGETYPE_WEBP];
        if ($info === false || !in_array($info[2], $allowed, true)) {
            echo json_encode(['success' => false, 'message' => 'Only JPG, PNG, GIF or WEBP images can be uploaded.']);
            break;
        }

        $extMap = [IMAGETYPE_JPEG => 'jpg', IMAGETYPE_PNG => 'png', IMAGETYPE_GIF => 'gif', IMAGETYPE_WEBP => 'webp'];
        $ext = $extMap[$info[2]];
        $name = 'img_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
        $destDir = dirname(__DIR__) . '/uploads';
        if (!is_dir($destDir)) {
            mkdir($destDir, 0755, true);
        }
        $dest = $destDir . '/' . $name;

        if (!move_uploaded_file($file['tmp_name'], $dest)) {
            echo json_encode(['success' => false, 'message' => 'The image could not be saved (check the uploads folder permissions).']);
            break;
        }

        echo json_encode([
            'success' => true,
            'message' => 'Image saved to the backend.',
            'url' => 'uploads/' . $name
        ]);
        break;

    case 'upload_pdf':
        // Homework / test paper PDF upload (logged-in admin only)
        require_login();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['success' => false, 'message' => 'Please send the PDF via POST.']);
            break;
        }
        if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
            echo json_encode(['success' => false, 'message' => 'No PDF was selected (or the upload failed).']);
            break;
        }

        $pdf = $_FILES['file'];
        $maxBytes = 10 * 1024 * 1024;
        if ($pdf['size'] > $maxBytes) {
            echo json_encode(['success' => false, 'message' => 'The PDF is larger than 10MB. Please upload a smaller file.']);
            break;
        }

        $ext = strtolower(pathinfo($pdf['name'], PATHINFO_EXTENSION));
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mime = $finfo->file($pdf['tmp_name']);
        if ($ext !== 'pdf' || $mime !== 'application/pdf') {
            echo json_encode(['success' => false, 'message' => 'Only PDF files can be uploaded.']);
            break;
        }

        $name = 'hw_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.pdf';
        $destDir = dirname(__DIR__) . '/uploads/homework';
        if (!is_dir($destDir)) {
            mkdir($destDir, 0755, true);
        }
        $dest = $destDir . '/' . $name;

        if (!move_uploaded_file($pdf['tmp_name'], $dest)) {
            echo json_encode(['success' => false, 'message' => 'The PDF could not be saved (check the uploads/homework folder permissions).']);
            break;
        }

        echo json_encode([
            'success' => true,
            'message' => 'PDF saved to the backend.',
            'url' => 'uploads/homework/' . $name
        ]);
        break;

    case 'list':
        // List of uploaded images
        $dir = dirname(__DIR__) . '/uploads';
        $files = [];
        if (is_dir($dir)) {
            foreach (scandir($dir) as $f) {
                if ($f === '.' || $f === '..') continue;
                if (!preg_match('/\.(jpe?g|png|gif|webp)$/i', $f)) continue;
                $files[] = [
                    'url' => 'uploads/' . $f,
                    'name' => $f,
                    'size' => filesize($dir . '/' . $f),
                    'modified' => date('Y-m-d H:i:s', filemtime($dir . '/' . $f))
                ];
            }
        }
        usort($files, function ($a, $b) { return strcmp($b['modified'], $a['modified']); });
        echo json_encode($files);
        break;

    default:
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
}
