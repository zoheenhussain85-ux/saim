<?php
require 'config.php';

header('Content-Type: application/json');

$action = $_GET['action'] ?? 'class_sheet';

function grade_for($percentage) {
    if ($percentage >= 80) return 'A+';
    if ($percentage >= 70) return 'A';
    if ($percentage >= 60) return 'B';
    if ($percentage >= 50) return 'C';
    if ($percentage >= 40) return 'D';
    return 'F';
}

function enrich_rows($rows) {
    foreach ($rows as $i => &$row) {
        $row['position'] = $i + 1;
        $row['percentage'] = round((float)$row['percentage'], 2);
        $row['grade'] = grade_for((float)$row['percentage']);
        $row['result'] = (float)$row['percentage'] >= 40 ? 'PASS' : 'FAIL';
    }
    unset($row);
    return $rows;
}

// Result aggregate for one class (with total marks, %, grade and position)
function class_aggregate($pdo, $class) {
    $stmt = $pdo->prepare("
        SELECT s.id AS student_id, s.full_name, s.parent_name, s.roll_no, s.admission_id,
               s.section, s.gender, s.student_group, s.current_class,
               COUNT(tr.id) AS tests_given,
               COALESCE(SUM(tr.marks_obtained), 0) AS obtained,
               COALESCE(SUM(tr.total_marks), 0) AS total,
               CASE WHEN COALESCE(SUM(tr.total_marks), 0) > 0
                    THEN ROUND(SUM(tr.marks_obtained) / SUM(tr.total_marks) * 100, 2)
                    ELSE 0 END AS percentage
        FROM students s
        LEFT JOIN test_reports tr ON tr.student_id = s.id
        WHERE s.current_class = ?
        GROUP BY s.id, s.full_name, s.parent_name, s.roll_no, s.admission_id,
                 s.section, s.gender, s.student_group, s.current_class
        ORDER BY percentage DESC, (s.roll_no+0), s.full_name
    ");
    $stmt->execute([$class]);
    return enrich_rows($stmt->fetchAll(PDO::FETCH_ASSOC));
}

switch ($action) {
    case 'class_sheet':
        // Result aggregate for one class: total marks, %, grade and position for every student
        $class = $_GET['class'] ?? '';
        if ($class === '') {
            echo json_encode(['success' => false, 'message' => 'Class is required.']);
            break;
        }
        log_activity('result_class_viewed', ['class' => $class]);
        echo json_encode(['success' => true, 'class' => $class, 'rows' => class_aggregate($pdo, $class)]);
        break;

    case 'multi_sheet':
        // Results for several classes at once (for the website's Result page)
        // classes=11,12 or classes=Nursery,KG,1
        $classes_raw = $_GET['classes'] ?? '';
        $classes = array_values(array_filter(array_map('trim', explode(',', $classes_raw)), 'strlen'));
        if (!$classes) {
            echo json_encode(['success' => false, 'message' => 'At least one class is required.']);
            break;
        }
        $rows = [];
        foreach ($classes as $class) {
            $rows = array_merge($rows, class_aggregate($pdo, $class));
        }
        log_activity('result_viewed', ['classes' => $classes]);
        echo json_encode(['success' => true, 'classes' => $classes, 'rows' => $rows]);
        break;

    case 'toppers':
        // Top students across the whole school (for gallery toppers)
        $limit = (int)($_GET['limit'] ?? 3);
        if ($limit <= 0) $limit = 3;
        if ($limit > 20) $limit = 20;

        $stmt = $pdo->prepare("
            SELECT s.id AS student_id, s.full_name, s.parent_name, s.roll_no, s.admission_id,
                   s.section, s.gender, s.student_group, s.current_class,
                   COUNT(tr.id) AS tests_given,
                   SUM(tr.marks_obtained) AS obtained,
                   SUM(tr.total_marks) AS total,
                   ROUND(SUM(tr.marks_obtained) / SUM(tr.total_marks) * 100, 2) AS percentage
            FROM students s
            INNER JOIN test_reports tr ON tr.student_id = s.id
            GROUP BY s.id, s.full_name, s.parent_name, s.roll_no, s.admission_id,
                     s.section, s.gender, s.student_group, s.current_class
            HAVING total > 0
            ORDER BY percentage DESC, (s.roll_no+0), s.full_name
            LIMIT $limit
        ");
        $stmt->execute();
        $rows = enrich_rows($stmt->fetchAll(PDO::FETCH_ASSOC));
        log_activity('toppers_viewed', ['limit' => $limit]);
        echo json_encode(['success' => true, 'rows' => $rows]);
        break;

    case 'test_sheet':
        // Class sheet for one test - previous marks are shown before uploading marks
        $test_id = (int)($_GET['test_id'] ?? 0);
        if ($test_id <= 0) {
            echo json_encode(['success' => false, 'message' => 'Test ID is required.']);
            break;
        }

        $stmt = $pdo->prepare("SELECT * FROM tests WHERE id = ?");
        $stmt->execute([$test_id]);
        $test = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$test) {
            echo json_encode(['success' => false, 'message' => 'Test not found.']);
            break;
        }

        $stmt = $pdo->prepare("
            SELECT s.id AS student_id, s.full_name, s.roll_no, s.admission_id, s.section,
                   tr.marks_obtained, tr.remarks
            FROM students s
            LEFT JOIN test_reports tr ON tr.student_id = s.id AND tr.test_id = ?
            WHERE s.current_class = ?
            ORDER BY (s.roll_no+0), s.full_name
        ");
        $stmt->execute([$test_id, $test['class_level']]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        log_activity('test_sheet_viewed', ['test_id' => $test_id, 'test_name' => $test['test_name'], 'class' => $test['class_level']]);
        echo json_encode(['success' => true, 'test' => $test, 'rows' => $rows]);
        break;

    case 'student_result':
        // Full result card data for one student
        $student_id = (int)($_GET['student_id'] ?? 0);
        if ($student_id <= 0) {
            echo json_encode(['success' => false, 'message' => 'Student ID is required.']);
            break;
        }

        $stmt = $pdo->prepare("SELECT * FROM students WHERE id = ?");
        $stmt->execute([$student_id]);
        $student = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$student) {
            log_activity('student_result_not_found', ['student_id' => $student_id]);
            echo json_encode(['success' => false, 'message' => 'Student not found.']);
            break;
        }

        $stmt = $pdo->prepare("
            SELECT tr.*, t.test_name, t.subject, t.total_marks AS test_total, t.passing_marks, t.test_date
            FROM test_reports tr
            INNER JOIN tests t ON tr.test_id = t.id
            WHERE tr.student_id = ?
            ORDER BY t.test_date, t.test_name
        ");
        $stmt->execute([$student_id]);
        $reports = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $obtained = 0;
        $total = 0;
        foreach ($reports as $report) {
            $obtained += (int)$report['marks_obtained'];
            $total += (int)$report['total_marks'];
        }
        $percentage = $total > 0 ? round($obtained / $total * 100, 2) : 0;

        log_activity('student_result_viewed', [
            'student' => $student['full_name'],
            'percentage' => $percentage
        ], [
            'student_id' => $student['id'],
            'student_name' => $student['full_name'],
            'class_level' => $student['current_class'],
            'roll_no' => $student['roll_no']
        ]);

        echo json_encode([
            'success' => true,
            'student' => $student,
            'reports' => $reports,
            'summary' => [
                'obtained' => $obtained,
                'total' => $total,
                'percentage' => $percentage,
                'grade' => grade_for($percentage),
                'result' => $percentage >= 40 ? 'PASS' : 'FAIL'
            ]
        ]);
        break;

    default:
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
}
