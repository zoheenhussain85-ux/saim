<?php
// auth.php - Admin panel login/logout and session check
require 'config.php';

header('Content-Type: application/json');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$action = $_GET['action'] ?? 'check';

if (!function_exists('clean')) {
    function clean($value)
    {
        return trim((string) $value);
    }
}

function current_user($pdo)
{
    $id = $_SESSION['admin_user_id'] ?? null;
    if (!$id)
        return null;
    $stmt = $pdo->prepare("SELECT id, username, full_name, role FROM users WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
}

switch ($action) {
    case 'login':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['success' => false, 'message' => 'Please log in via POST.']);
            break;
        }

        $contentType = $_SERVER['CONTENT_TYPE'] ?? '';
        if (strpos($contentType, 'application/json') !== false) {
            $body = json_decode(file_get_contents('php://input'), true) ?: [];
            $username = clean($body['username'] ?? '');
            $password = (string) ($body['password'] ?? '');
        } else {
            $username = clean($_POST['username'] ?? '');
            $password = (string) ($_POST['password'] ?? '');
        }

        if ($username === '' || $password === '') {
            echo json_encode(['success' => false, 'message' => 'Username and password are both required.']);
            break;
        }

        // Fetching the username from the database table 'users'
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? OR email = ? LIMIT 1");
        $stmt->execute([$username, $username]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        // MODIFIED: Changed from password_verify() to direct plain text comparison
        if (!$user || $password !== $user['password']) {
            // Small delay before responding to make brute-force harder
            usleep(300000);
            log_activity('admin_login_failed', ['username' => $username]);
            echo json_encode(['success' => false, 'message' => 'Incorrect username or password.']);
            break;
        }

        session_regenerate_id(true);
        $_SESSION['admin_user_id'] = (int) $user['id'];
        $_SESSION['admin_username'] = $user['username'];
        $_SESSION['admin_role'] = $user['role'];

        log_activity('admin_login', ['username' => $user['username']]);

        echo json_encode([
            'success' => true,
            'message' => 'Logged in.',
            'user' => [
                'id' => (int) $user['id'],
                'username' => $user['username'],
                'full_name' => $user['full_name'],
                'role' => $user['role']
            ]
        ]);
        break;

    case 'check':
        // Whether currently logged in (called on admin.html page load)
        $user = current_user($pdo);
        if ($user) {
            echo json_encode(['success' => true, 'logged_in' => true, 'user' => $user]);
        } else {
            echo json_encode(['success' => true, 'logged_in' => false]);
        }
        break;

    case 'logout':
        log_activity('admin_logout');
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $p = session_get_cookie_params();
            setcookie(
                session_name(),
                '',
                time() - 42000,
                $p['path'],
                $p['domain'],
                $p['secure'],
                $p['httponly']
            );
        }
        session_destroy();
        echo json_encode(['success' => true, 'message' => 'Logged out.']);
        break;

    default:
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
}
