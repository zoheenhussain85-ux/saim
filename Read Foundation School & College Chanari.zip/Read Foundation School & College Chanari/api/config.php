<?php
// config.php - Database configuration for Foundation School & College Chanari
$host = "localhost";
$db = "foundation_school_chanari";
$user = "root";  // change as needed
$pass = "";      // change as needed
$port = 3306;
$charset = "utf8mb4";

$dsn = "mysql:host=$host;dbname=$db;port=$port;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    throw new \PDOException($e->getMessage(), (int)$e->getCode());
}

// Admin login check. Public pages (result/attendance/report/gallery) read APIs
// and work without it. Mutation APIs call it to force login.
function admin_user_id() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    return $_SESSION['admin_user_id'] ?? null;
}

function require_login() {
    if (admin_user_id() === null) {
        header('Content-Type: application/json');
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Login required. Please log in from the admin panel.']);
        exit;
    }
}

// ------------------------------------------------------------------
// ACTIVITY LOG (backend only - no UI in the frontend)
// Every important action on the website is recorded in the database: who
// (IP), what was viewed (result / report / attendance), when, and which page.
// To view: api/activity.php (admin login required).
// If logging fails, the actual work must never stop - hence try/catch.
// ------------------------------------------------------------------
function log_activity($action, $detail = null, $extra = []) {
    try {
        global $pdo;
        if (!$pdo instanceof PDO) return;

        $actor_id = admin_user_id();
        $stmt = $pdo->prepare("
            INSERT INTO activity_log
                (actor_type, admin_user_id, student_id, student_name, class_level,
                 roll_no, action, page, detail, ip_address, user_agent, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
        ");
        $stmt->execute([
            $actor_id !== null ? 'admin' : 'guest',
            $actor_id,
            isset($extra['student_id']) && $extra['student_id'] !== '' ? (int)$extra['student_id'] : null,
            isset($extra['student_name']) ? mb_substr((string)$extra['student_name'], 0, 120) : null,
            isset($extra['class_level']) && $extra['class_level'] !== '' ? mb_substr((string)$extra['class_level'], 0, 20) : null,
            isset($extra['roll_no']) && $extra['roll_no'] !== '' ? mb_substr((string)$extra['roll_no'], 0, 20) : null,
            mb_substr((string)$action, 0, 50),
            basename((string)($_SERVER['SCRIPT_NAME'] ?? '')),
            $detail !== null && $detail !== [] ? mb_substr(json_encode($detail, JSON_UNESCAPED_UNICODE), 0, 500) : null,
            $_SERVER['REMOTE_ADDR'] ?? null,
            isset($_SERVER['HTTP_USER_AGENT']) ? mb_substr((string)$_SERVER['HTTP_USER_AGENT'], 0, 255) : null,
        ]);
    } catch (\Throwable $e) {
        // silent - a failed activity log should not block the request
    }
}