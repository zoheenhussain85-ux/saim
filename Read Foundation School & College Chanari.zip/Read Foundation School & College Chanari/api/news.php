<?php
require 'config.php';

header('Content-Type: application/json');

$stmt = $pdo->query("SELECT n.*, u.full_name as published_by_name FROM news n LEFT JOIN users u ON n.published_by = u.id ORDER BY n.published_at DESC");
$news = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($news);