<?php
require 'config.php';

header('Content-Type: application/json');

$stmt = $pdo->query("SELECT g.*, u.full_name as uploaded_by_name FROM gallery g LEFT JOIN users u ON g.uploaded_by = u.id ORDER BY g.uploaded_at DESC");
$photos = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($photos);