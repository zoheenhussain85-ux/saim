-- =============================================
-- UPGRADE v2: Purane database ke liye nayi cheezein
-- phpMyAdmin > foundation_school_chanari > Import se yeh file chalayein.
-- Naya setup? To sirf schema.sql import karein.
-- =============================================

-- 1) Attendance table
CREATE TABLE IF NOT EXISTS attendance (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    att_date DATE NOT NULL,
    status ENUM('present', 'absent', 'late', 'leave') NOT NULL DEFAULT 'present',
    remarks VARCHAR(255),
    recorded_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_student_date (student_id, att_date),
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (recorded_by) REFERENCES users(id) ON DELETE SET NULL
);

-- 2) Test report mein duplicate marks rokne ke liye unique key
-- Agar "Duplicate key name" error aaye to koi masla nahi - key pehle se hai
ALTER TABLE test_reports ADD UNIQUE KEY uq_student_test (student_id, test_id);

-- 3) Test/Exam mein section, group aur report image ke liye naye columns
ALTER TABLE tests ADD COLUMN section VARCHAR(20) AFTER class_level;
ALTER TABLE tests ADD COLUMN group_name VARCHAR(30) AFTER section;
ALTER TABLE tests ADD COLUMN image_url VARCHAR(255) AFTER group_name;

-- 4) Student mein college group (ICS / Pre-Medical / I.Com etc.) ke liye column
ALTER TABLE students ADD COLUMN student_group VARCHAR(30) AFTER section;
