-- =============================================
-- UPGRADE FILE: Purane database ke liye
-- Agar aapne pehle se sql/schema.sql import kar chuka hai,
-- to sirf yeh file import karein (phpMyAdmin > Import).
-- Naya setup hai? To sirf schema.sql import karein, yeh nahi.
-- =============================================

-- 1) Attendance ki nayi table (agar pehle se hai to chhod dega)
CREATE TABLE IF NOT EXISTS attendance (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    att_date DATE NOT NULL,
    status ENUM('present', 'absent', 'late', 'leave') NOT NULL DEFAULT 'present',
    remarks VARCHAR(255),
    recorded_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_student_date (student_id, att_date),
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (recorded_by) REFERENCES users(id) ON DELETE SET NULL
);

-- 2) Test report mein duplicate rokne ke liye unique key
-- Agar error aaye "Duplicate key name" to koi baat nahi - key pehle se maujood hai
ALTER TABLE test_reports ADD UNIQUE KEY uq_student_test (student_id, test_id);
