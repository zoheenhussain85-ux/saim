-- =============================================
-- ACTIVITY LOG: Website par kya kya hua
-- (student/guest ke actions aur admin ke kaam) - sirf backend record
-- phpMyAdmin > foundation_school_chanari > Import se chalayein.
-- Dobara chalana safe hai (IF NOT EXISTS).
-- =============================================

CREATE TABLE IF NOT EXISTS activity_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    actor_type ENUM('guest','admin') NOT NULL DEFAULT 'guest',
    admin_user_id INT NULL,
    student_id INT NULL,
    student_name VARCHAR(120) NULL,
    class_level VARCHAR(20) NULL,
    roll_no VARCHAR(20) NULL,
    action VARCHAR(50) NOT NULL,
    page VARCHAR(40) NULL,
    detail VARCHAR(500) NULL,
    ip_address VARCHAR(45) NULL,
    user_agent VARCHAR(255) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY idx_activity_created (created_at),
    KEY idx_activity_action (action),
    KEY idx_activity_roll (roll_no),
    KEY idx_activity_ip (ip_address),
    KEY idx_activity_student (student_id)
);
