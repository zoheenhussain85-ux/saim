-- =============================================
-- UPGRADE: Student ki photo ka column
-- Purane database ke liye phpMyAdmin > foundation_school_chanari > Import.
-- Agar column pehle se maujood hai to "Duplicate column" error aayega -
-- us case mein koi masla nahi, column pehle se hai.
-- Naya setup? Sirf schema.sql import karein.
-- =============================================

ALTER TABLE students ADD COLUMN image_url VARCHAR(255) AFTER blood_group;
