-- Homework / Test upload table
-- Import this file in phpMyAdmin if you want to create the table manually.
-- api/homework.php bhi table na hone par khud bana leta hai.

CREATE TABLE IF NOT EXISTS homework (
    id INT AUTO_INCREMENT PRIMARY KEY,
    type ENUM('test', 'homework') NOT NULL DEFAULT 'homework',
    class_level VARCHAR(50) NOT NULL,
    subject VARCHAR(80) NOT NULL,
    title VARCHAR(150) NOT NULL,
    description TEXT,
    assigned_date DATE NULL,
    due_date DATE NULL,
    file_url VARCHAR(255) NULL,
    created_by INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY idx_hw_class (class_level),
    KEY idx_hw_assigned (assigned_date)
);
