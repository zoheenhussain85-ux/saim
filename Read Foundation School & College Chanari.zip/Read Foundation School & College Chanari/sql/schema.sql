-- Database: foundation_school_chanari
-- Created for Foundation School & College, Chanari
-- Established: December 7, 1994
-- Under: Foundation Trust

-- =============================================
-- DROP EXISTING TABLES (for fresh setup)
-- =============================================

DROP TABLE IF EXISTS attendance;
DROP TABLE IF EXISTS test_reports;
DROP TABLE IF EXISTS tests;
DROP TABLE IF EXISTS students;
DROP TABLE IF EXISTS admission_inquiries;
DROP TABLE IF EXISTS events;
DROP TABLE IF EXISTS gallery;
DROP TABLE IF EXISTS news;
DROP TABLE IF EXISTS staff;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS settings;

-- =============================================
-- TABLE: users (admin/staff authentication)
-- =============================================

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    role ENUM('admin', 'teacher', 'staff') DEFAULT 'teacher',
    email VARCHAR(100) UNIQUE,
    phone VARCHAR(20),
    address TEXT,
    profile_image VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- =============================================
-- TABLE: staff (teaching and non-teaching staff details)
-- =============================================

CREATE TABLE staff (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    qualification VARCHAR(100),
    subject VARCHAR(50),
    joining_date DATE,
    experience_years INT,
    email VARCHAR(100),
    phone VARCHAR(20),
    image_url VARCHAR(255),
    status ENUM('active', 'inactive', 'on_leave') DEFAULT 'active',
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- =============================================
-- TABLE: news (school news and announcements)
-- =============================================

CREATE TABLE news (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    content TEXT NOT NULL,
    image_url VARCHAR(255),
    category ENUM('general', 'academic', 'event', 'achievement', 'holiday') DEFAULT 'general',
    published_by INT,
    published_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('draft', 'published', 'archived') DEFAULT 'published',
    FOREIGN KEY (published_by) REFERENCES users(id) ON DELETE SET NULL
);

-- =============================================
-- TABLE: gallery (photo gallery images)
-- =============================================

CREATE TABLE gallery (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    description TEXT,
    image_url VARCHAR(255) NOT NULL,
    category ENUM('event', 'campus', 'staff', 'students', 'achievement') DEFAULT 'campus',
    uploaded_by INT,
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (uploaded_by) REFERENCES users(id) ON DELETE SET NULL
);

-- =============================================
-- TABLE: events (school events and functions)
-- =============================================

CREATE TABLE events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    description TEXT,
    event_date DATE NOT NULL,
    event_time TIME,
    location VARCHAR(100),
    image_url VARCHAR(255),
    category ENUM('academic', 'cultural', 'sports', 'examination', 'parent_meeting') DEFAULT 'academic',
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('upcoming', 'ongoing', 'completed', 'cancelled') DEFAULT 'upcoming',
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
);

-- =============================================
-- TABLE: admission_inquiries (online admission forms)
-- =============================================

CREATE TABLE admission_inquiries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    phone VARCHAR(20),
    current_class VARCHAR(50),
    applying_for_class VARCHAR(50) NOT NULL,
    date_of_birth DATE,
    gender ENUM('male', 'female', 'other'),
    address TEXT,
    parent_name VARCHAR(100),
    previous_school VARCHAR(100),
    comments TEXT,
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('new', 'viewed', 'contacted', 'admitted', 'rejected') DEFAULT 'new',
    ip_address VARCHAR(45)
);

-- =============================================
-- TABLE: settings (school information)
-- =============================================

CREATE TABLE settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    school_name VARCHAR(100) NOT NULL,
    school_address TEXT,
    phone VARCHAR(20),
    email VARCHAR(100),
    website VARCHAR(100),
    established_year YEAR,
    trust_name VARCHAR(100),
    curriculum VARCHAR(50),
    principal_name VARCHAR(100),
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- =============================================
-- INSERT DEFAULT SETTINGS
-- =============================================

INSERT INTO settings (school_name, school_address, phone, email, website, established_year, trust_name, curriculum, principal_name) VALUES 
('Foundation School & College', 'Chanari', '+880 1712 345678', 'info@fsnchanari.edu', 'www.fsnchanari.edu', 1994, 'Foundation Trust', 'English Version', 'Principal Name');

-- =============================================
-- SAMPLE DATA INSERTS (for testing)
-- =============================================

-- Admin user
INSERT INTO users (username, password, full_name, role, email, phone) VALUES 
('admin', '$2y$10$92IXUNpkjO0dOJOdGCLSE2uWlK0ZYk5QExO3ZjTI.86UevB2lZ8oq', 'System Administrator', 'admin', 'admin@fsnchanari.edu', '+880 1712 000000');

-- Sample teacher
INSERT INTO users (username, password, full_name, role, email, phone) VALUES 
('teacher1', '$2y$10$92IXUNpkjO0dOJOdGCLSE2uWlK0ZYk5QExO3ZjTI.86UevB2lZ8oq', 'Rahim Islam', 'teacher', 'rahim@fsnchanari.edu', '+880 1712 111111');

INSERT INTO staff (user_id, qualification, subject, joining_date, experience_years, email, phone) VALUES 
(2, 'M.A, B.Ed', 'Mathematics', '2010-01-15', 12, 'rahim@fsnchanari.edu', '+880 1712 111111');

-- Sample news
INSERT INTO news (title, content, category, published_by) VALUES 
('School Anniversary Celebration', 'Foundation School & College Chanari celebrated its anniversary with great enthusiasm...', 'event', 1);

-- Sample gallery images
INSERT INTO gallery (title, description, image_url, category) VALUES 
('Foundation Day Celebration', '1994 Foundation Day ceremony', 'uploads/foundation_day.jpg', 'event');

-- Sample events
INSERT INTO events (title, description, event_date, location, category, created_by) VALUES 
('Annual Sports Day', 'Annual sports and games competition', '2024-12-15', 'School Playground', 'sports', 1);

-- Sample admission inquiries (commented out - would be created via form)
-- INSERT INTO admission_inquiries (full_name, email, phone, applying_for_class) VALUES ('Test Student', 'test@test.com', '1234567890', 'Class 1');

-- =============================================
-- TABLE: students (student records)
-- =============================================

CREATE TABLE students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    admission_id VARCHAR(20) UNIQUE NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    date_of_birth DATE,
    gender ENUM('male', 'female', 'other') DEFAULT 'male',
    current_class VARCHAR(50) NOT NULL,
    section VARCHAR(10),
    student_group VARCHAR(30),
    roll_no VARCHAR(20),
    email VARCHAR(100),
    phone VARCHAR(20),
    address TEXT,
    parent_name VARCHAR(100),
    date_of_admission DATE,
    blood_group VARCHAR(5),
    image_url VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- =============================================
-- TABLE: tests (test/exam definitions)
-- =============================================

CREATE TABLE tests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    test_name VARCHAR(100) NOT NULL,
    subject VARCHAR(50) NOT NULL,
    class_level VARCHAR(50) NOT NULL,
    section VARCHAR(20),
    group_name VARCHAR(30),
    image_url VARCHAR(255),
    total_marks INT DEFAULT 100,
    passing_marks INT DEFAULT 33,
    test_date DATE,
    description TEXT,
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('active', 'completed', 'archived') DEFAULT 'active',
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
);

-- =============================================
-- TABLE: test_reports (student test results)
-- =============================================

CREATE TABLE test_reports (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    test_id INT NOT NULL,
    marks_obtained INT DEFAULT 0,
    total_marks INT DEFAULT 100,
    percentage DECIMAL(5,2) DEFAULT 0.00,
    grade ENUM('A+', 'A', 'B', 'C', 'D', 'F') DEFAULT 'F',
    attended BOOLEAN DEFAULT TRUE,
    remarks TEXT,
    report_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_student_test (student_id, test_id),
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (test_id) REFERENCES tests(id) ON DELETE CASCADE
);

-- =============================================
-- TABLE: attendance (daily class attendance)
-- =============================================

CREATE TABLE attendance (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    att_date DATE NOT NULL,
    status ENUM('present', 'absent', 'late', 'leave') NOT NULL DEFAULT 'present',
    remarks VARCHAR(255),
    recorded_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_student_date (student_id, att_date),
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (recorded_by) REFERENCES users(id) ON DELETE SET NULL
);

-- =============================================
-- ACTIVITY LOG: Website par kya kya hua (sirf backend record)
-- =============================================

CREATE TABLE activity_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    actor_type ENUM('guest','admin') NOT NULL DEFAULT 'guest',
    admin_user_id INT NULL,
    student_id INT NULL,
    student_name VARCHAR(120) NULL,
    class_level VARCHAR(20) NULL,
    roll_no VARCHAR(20) NULL,
    action VARCHAR(50) NOT NULL,
    page VARCHAR(40) NULL,
    detail VARCHAR(500) NULL,
    ip_address VARCHAR(45) NULL,
    user_agent VARCHAR(255) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY idx_activity_created (created_at),
    KEY idx_activity_action (action),
    KEY idx_activity_roll (roll_no),
    KEY idx_activity_ip (ip_address),
    KEY idx_activity_student (student_id)
);

-- =============================================
-- INSERT SAMPLE DATA
-- =============================================

-- Sample students
INSERT INTO students (admission_id, full_name, date_of_birth, gender, current_class, section, roll_no, email, phone, address, parent_name, date_of_admission, blood_group) VALUES 
('FS2024-001', 'Ahmed Khan', '2015-03-15', 'male', '5', 'A', '001', 'ahmed@fsnchanari.edu', '+880 1712 100001', 'Chanari, Dhaka', 'Mr. Khan', '2024-01-15', 'O+');
INSERT INTO students (admission_id, full_name, date_of_birth, gender, current_class, section, roll_no, email, phone, address, parent_name, date_of_admission, blood_group) VALUES 
('FS2024-002', 'Fatima Begum', '2016-07-22', 'female', '5', 'B', '002', 'fatima@fsnchanari.edu', '+880 1712 100002', 'Chanari, Dhaka', 'Mr. Begum', '2024-01-18', 'A+');

-- Sample tests
INSERT INTO tests (test_name, subject, class_level, total_marks, passing_marks, test_date, description, created_by) VALUES 
('Mid-Term Exam', 'Mathematics', '5', 100, 33, '2024-01-20', 'First term mathematics examination', 1);
INSERT INTO tests (test_name, subject, class_level, total_marks, passing_marks, test_date, description, created_by) VALUES 
('Science Quiz', 'Science', '5', 50, 20, '2024-01-25', 'General science quiz', 1);

-- Sample test reports
INSERT INTO test_reports (student_id, test_id, marks_obtained, total_marks, percentage, grade, attended, remarks) VALUES 
(1, 1, 85, 100, 85.00, 'A', TRUE, 'Excellent performance in mathematics');
INSERT INTO test_reports (student_id, test_id, marks_obtained, total_marks, percentage, grade, attended, remarks) VALUES 
(2, 1, 72, 100, 72.00, 'B', TRUE, 'Good performance, needs improvement in algebra');
INSERT INTO test_reports (student_id, test_id, marks_obtained, total_marks, percentage, grade, attended, remarks) VALUES 
(1, 2, 45, 50, 90.00, 'A+', TRUE, 'Outstanding in science quiz');
INSERT INTO test_reports (student_id, test_id, marks_obtained, total_marks, percentage, grade, attended, remarks) VALUES 
(2, 2, 35, 50, 70.00, 'A', TRUE, 'Very good performance');

-- Sample attendance
INSERT INTO attendance (student_id, att_date, status) VALUES 
(1, '2024-01-15', 'present'), (2, '2024-01-15', 'late');
INSERT INTO attendance (student_id, att_date, status) VALUES 
(1, '2024-01-16', 'absent'), (2, '2024-01-16', 'present');