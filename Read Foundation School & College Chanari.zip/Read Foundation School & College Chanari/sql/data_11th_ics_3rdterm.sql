-- =============================================
-- DATA: Class 11 (11th) - Section boys - Group ICS
-- Exam: 3rd Term Test - Image: uploads/sa.png
-- Marks sheet se enter kiya gaya (18 students, 7 subjects)
-- Dobara chalana safe hai (purana data delete ho kar naya insert hota hai)
-- =============================================

DELETE tr FROM test_reports tr
INNER JOIN tests t ON tr.test_id = t.id
WHERE t.test_name = '3rd Term Test' AND t.class_level = '11' AND t.section = 'boys' AND t.group_name = 'ICS';

DELETE FROM tests
WHERE test_name = '3rd Term Test' AND class_level = '11' AND section = 'boys' AND group_name = 'ICS';

DELETE FROM students
WHERE admission_id IN ('FS2026-101','FS2026-102','FS2026-103','FS2026-104','FS2026-105','FS2026-106','FS2026-107','FS2026-108','FS2026-109','FS2026-110','FS2026-111','FS2026-112','FS2026-113','FS2026-114','FS2026-115','FS2026-116','FS2026-117','FS2026-118');

-- 18 students (roll 1-18, class 11, section boys, group ICS)
INSERT INTO students (admission_id, full_name, gender, current_class, section, student_group, roll_no) VALUES
('FS2026-101', 'adnan',   'male', '11', 'boys', 'ICS', '1'),
('FS2026-102', 'sabit',   'male', '11', 'boys', 'ICS', '2'),
('FS2026-103', 'saim',    'male', '11', 'boys', 'ICS', '3'),
('FS2026-104', 'sultan',  'male', '11', 'boys', 'ICS', '4'),
('FS2026-105', 'bilwal',  'male', '11', 'boys', 'ICS', '5'),
('FS2026-106', 'noshad',  'male', '11', 'boys', 'ICS', '6'),
('FS2026-107', 'subhan',  'male', '11', 'boys', 'ICS', '7'),
('FS2026-108', 'rasalat', 'male', '11', 'boys', 'ICS', '8'),
('FS2026-109', 'aman',    'male', '11', 'boys', 'ICS', '9'),
('FS2026-110', 'sami',    'male', '11', 'boys', 'ICS', '10'),
('FS2026-111', 'ali',     'male', '11', 'boys', 'ICS', '11'),
('FS2026-112', 'daim',    'male', '11', 'boys', 'ICS', '12'),
('FS2026-113', 'toseeq',  'male', '11', 'boys', 'ICS', '13'),
('FS2026-114', 'asad',    'male', '11', 'boys', 'ICS', '14'),
('FS2026-115', 'huzaifa', 'male', '11', 'boys', 'ICS', '15'),
('FS2026-116', 'iqram',   'male', '11', 'boys', 'ICS', '16'),
('FS2026-117', 'imran',   'male', '11', 'boys', 'ICS', '17'),
('FS2026-118', 'uzair',   'male', '11', 'boys', 'ICS', '18');

-- 7 subjects = 7 tests (3rd Term Test), image uploads/sa.png ke sath
INSERT INTO tests (test_name, subject, class_level, section, group_name, image_url, total_marks, passing_marks, test_date, description) VALUES
('3rd Term Test', 'english',  '11', 'boys', 'ICS', 'uploads/sa.png', 100, 40, '2026-10-14', '3rd Term Test - Class 11 ICS Boys'),
('3rd Term Test', 'urdu',     '11', 'boys', 'ICS', 'uploads/sa.png', 100, 40, '2026-10-14', '3rd Term Test - Class 11 ICS Boys'),
('3rd Term Test', 'math',     '11', 'boys', 'ICS', 'uploads/sa.png', 100, 40, '2026-10-14', '3rd Term Test - Class 11 ICS Boys'),
('3rd Term Test', 'physics',  '11', 'boys', 'ICS', 'uploads/sa.png',  85, 34, '2026-10-14', '3rd Term Test - Class 11 ICS Boys'),
('3rd Term Test', 'computer', '11', 'boys', 'ICS', 'uploads/sa.png',  75, 30, '2026-10-14', '3rd Term Test - Class 11 ICS Boys'),
('3rd Term Test', 'islamiat', '11', 'boys', 'ICS', 'uploads/sa.png',  50, 20, '2026-10-14', '3rd Term Test - Class 11 ICS Boys'),
('3rd Term Test', 'uqc',      '11', 'boys', 'ICS', 'uploads/sa.png',  50, 20, '2026-10-14', '3rd Term Test - Class 11 ICS Boys');

-- English marks
INSERT INTO test_reports (student_id, test_id, marks_obtained, total_marks, attended)
SELECT s.id, t.id,
  CASE s.roll_no WHEN '1' THEN 99 WHEN '2' THEN 98 WHEN '3' THEN 97 WHEN '4' THEN 67 WHEN '5' THEN 56 WHEN '6' THEN 45 WHEN '7' THEN 76 WHEN '8' THEN 45 WHEN '9' THEN 65 WHEN '10' THEN 76 WHEN '11' THEN 23 WHEN '12' THEN 56 WHEN '13' THEN 87 WHEN '14' THEN 98 WHEN '15' THEN 67 WHEN '16' THEN 67 WHEN '17' THEN 23 WHEN '18' THEN 23 END,
  t.total_marks, 1
FROM students s CROSS JOIN tests t
WHERE s.admission_id LIKE 'FS2026-1%' AND s.current_class = '11' AND s.student_group = 'ICS'
  AND t.test_name = '3rd Term Test' AND t.subject = 'english' AND t.class_level = '11' AND t.section = 'boys' AND t.group_name = 'ICS';

-- Urdu marks
INSERT INTO test_reports (student_id, test_id, marks_obtained, total_marks, attended)
SELECT s.id, t.id,
  CASE s.roll_no WHEN '1' THEN 67 WHEN '2' THEN 56 WHEN '3' THEN 13 WHEN '4' THEN 23 WHEN '5' THEN 65 WHEN '6' THEN 78 WHEN '7' THEN 77 WHEN '8' THEN 56 WHEN '9' THEN 0 WHEN '10' THEN 12 WHEN '11' THEN 22 WHEN '12' THEN 44 WHEN '13' THEN 5 WHEN '14' THEN 55 WHEN '15' THEN 76 WHEN '16' THEN 88 WHEN '17' THEN 98 WHEN '18' THEN 10 END,
  t.total_marks, 1
FROM students s CROSS JOIN tests t
WHERE s.admission_id LIKE 'FS2026-1%' AND s.current_class = '11' AND s.student_group = 'ICS'
  AND t.test_name = '3rd Term Test' AND t.subject = 'urdu' AND t.class_level = '11' AND t.section = 'boys' AND t.group_name = 'ICS';

-- Math marks
INSERT INTO test_reports (student_id, test_id, marks_obtained, total_marks, attended)
SELECT s.id, t.id,
  CASE s.roll_no WHEN '1' THEN 70 WHEN '2' THEN 81 WHEN '3' THEN 67 WHEN '4' THEN 54 WHEN '5' THEN 65 WHEN '6' THEN 76 WHEN '7' THEN 54 WHEN '8' THEN 45 WHEN '9' THEN 56 WHEN '10' THEN 32 WHEN '11' THEN 23 WHEN '12' THEN 12 WHEN '13' THEN 56 WHEN '14' THEN 66 WHEN '15' THEN 54 WHEN '16' THEN 78 WHEN '17' THEN 12 WHEN '18' THEN 24 END,
  t.total_marks, 1
FROM students s CROSS JOIN tests t
WHERE s.admission_id LIKE 'FS2026-1%' AND s.current_class = '11' AND s.student_group = 'ICS'
  AND t.test_name = '3rd Term Test' AND t.subject = 'math' AND t.class_level = '11' AND t.section = 'boys' AND t.group_name = 'ICS';

-- Physics marks
INSERT INTO test_reports (student_id, test_id, marks_obtained, total_marks, attended)
SELECT s.id, t.id,
  CASE s.roll_no WHEN '1' THEN 54 WHEN '2' THEN 54 WHEN '3' THEN 34 WHEN '4' THEN 23 WHEN '5' THEN 32 WHEN '6' THEN 23 WHEN '7' THEN 34 WHEN '8' THEN 44 WHEN '9' THEN 54 WHEN '10' THEN 5 WHEN '11' THEN 76 WHEN '12' THEN 78 WHEN '13' THEN 67 WHEN '14' THEN 56 WHEN '15' THEN 34 WHEN '16' THEN 12 WHEN '17' THEN 22 WHEN '18' THEN 20 END,
  t.total_marks, 1
FROM students s CROSS JOIN tests t
WHERE s.admission_id LIKE 'FS2026-1%' AND s.current_class = '11' AND s.student_group = 'ICS'
  AND t.test_name = '3rd Term Test' AND t.subject = 'physics' AND t.class_level = '11' AND t.section = 'boys' AND t.group_name = 'ICS';

-- Computer marks
INSERT INTO test_reports (student_id, test_id, marks_obtained, total_marks, attended)
SELECT s.id, t.id,
  CASE s.roll_no WHEN '1' THEN 54 WHEN '2' THEN 23 WHEN '3' THEN 3 WHEN '4' THEN 34 WHEN '5' THEN 34 WHEN '6' THEN 23 WHEN '7' THEN 23 WHEN '8' THEN 3 WHEN '9' THEN 23 WHEN '10' THEN 33 WHEN '11' THEN 34 WHEN '12' THEN 34 WHEN '13' THEN 4 WHEN '14' THEN 54 WHEN '15' THEN 54 WHEN '16' THEN 2 WHEN '17' THEN 23 WHEN '18' THEN 13 END,
  t.total_marks, 1
FROM students s CROSS JOIN tests t
WHERE s.admission_id LIKE 'FS2026-1%' AND s.current_class = '11' AND s.student_group = 'ICS'
  AND t.test_name = '3rd Term Test' AND t.subject = 'computer' AND t.class_level = '11' AND t.section = 'boys' AND t.group_name = 'ICS';

-- Islamiat marks
INSERT INTO test_reports (student_id, test_id, marks_obtained, total_marks, attended)
SELECT s.id, t.id,
  CASE s.roll_no WHEN '1' THEN 45 WHEN '2' THEN 23 WHEN '3' THEN 23 WHEN '4' THEN 33 WHEN '5' THEN 23 WHEN '6' THEN 23 WHEN '7' THEN 33 WHEN '8' THEN 3 WHEN '9' THEN 0 WHEN '10' THEN 4 WHEN '11' THEN 23 WHEN '12' THEN 23 WHEN '13' THEN 22 WHEN '14' THEN 2 WHEN '15' THEN 23 WHEN '16' THEN 12 WHEN '17' THEN 32 WHEN '18' THEN 43 END,
  t.total_marks, 1
FROM students s CROSS JOIN tests t
WHERE s.admission_id LIKE 'FS2026-1%' AND s.current_class = '11' AND s.student_group = 'ICS'
  AND t.test_name = '3rd Term Test' AND t.subject = 'islamiat' AND t.class_level = '11' AND t.section = 'boys' AND t.group_name = 'ICS';

-- UQC marks
INSERT INTO test_reports (student_id, test_id, marks_obtained, total_marks, attended)
SELECT s.id, t.id,
  CASE s.roll_no WHEN '1' THEN 49 WHEN '2' THEN 12 WHEN '3' THEN 34 WHEN '4' THEN 45 WHEN '5' THEN 33 WHEN '6' THEN 22 WHEN '7' THEN 23 WHEN '8' THEN 45 WHEN '9' THEN 54 WHEN '10' THEN 45 WHEN '11' THEN 45 WHEN '12' THEN 45 WHEN '13' THEN 23 WHEN '14' THEN 43 WHEN '15' THEN 23 WHEN '16' THEN 45 WHEN '17' THEN 34 WHEN '18' THEN 31 END,
  t.total_marks, 1
FROM students s CROSS JOIN tests t
WHERE s.admission_id LIKE 'FS2026-1%' AND s.current_class = '11' AND s.student_group = 'ICS'
  AND t.test_name = '3rd Term Test' AND t.subject = 'uqc' AND t.class_level = '11' AND t.section = 'boys' AND t.group_name = 'ICS';

-- Percentage aur grade khud calculate karein (A+ 80, A 70, B 60, C 50, D 40, warna F)
UPDATE test_reports tr
JOIN tests t ON tr.test_id = t.id
SET tr.percentage = ROUND(tr.marks_obtained * 100.0 / tr.total_marks, 2),
    tr.grade = CASE
      WHEN tr.marks_obtained * 100.0 / tr.total_marks >= 80 THEN 'A+'
      WHEN tr.marks_obtained * 100.0 / tr.total_marks >= 70 THEN 'A'
      WHEN tr.marks_obtained * 100.0 / tr.total_marks >= 60 THEN 'B'
      WHEN tr.marks_obtained * 100.0 / tr.total_marks >= 50 THEN 'C'
      WHEN tr.marks_obtained * 100.0 / tr.total_marks >= 40 THEN 'D'
      ELSE 'F'
    END
WHERE t.test_name = '3rd Term Test' AND t.class_level = '11' AND t.section = 'boys' AND t.group_name = 'ICS';
