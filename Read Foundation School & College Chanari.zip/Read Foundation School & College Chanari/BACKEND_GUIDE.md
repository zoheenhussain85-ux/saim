# Backend Guide (english)

Is website ka backend **`api/` folder** hai. Is mein MySQL database lagta hai — yani student ka **result**, **test report** aur **attendance** internet par save hote hain (browser ki local memory mein nahi).

---

## 1. Setup (sirf ek dafa karna hai)

1. **XAMPP** install karein (agar nahi hai) aur **Apache** + **MySQL** dono **Start** karein (XAMPP Control Panel se).
2. Is project folder ko copy karein yahan:
   `C:\xampp\htdocs\`
   (Example: `C:\xampp\htdocs\New folder (2)\`)
3. Browser mein kholein: `http://localhost/phpmyadmin`
4. **New database** banayein — naam rakhein:
   ` Read_Foundation_School_&_College_chanari`
5. Us database ko kholein → **Import** tab → file choose karein **`sql/schema.sql`** → **Go** dabayein.
6. **Zaroori:** `api/config.php` file mein database ka naam, username aur password check karein.
   XAMPP mein default yeh hota hai:
   - host: `localhost`
   - db: `foundation_school_chanari`
   - user: `root`
   - pass: _(khali)_

### Agar database pehle se bana hua hai (purana setup)?

To sirf **`sql/upgrade_v2.sql`** import karein. Is se attendance ki table, duplicate marks rokne ki key, aur test mein section/group/image ke naye columns ban jayen ge. _(Agar "Duplicate key name" ya "Duplicate column" jaisa error aaye to koi masla nahi — cheezein pehle se maujood hain.)_

**Note:** Is project ki working copy htdocs mein yahan hai:
`C:\xampp\htdocs\foundation-school\`
Admin panel: **http://localhost/foundation-school/admin.html**

**Website ke public pages (Result, Daily Attendance, Test Report, Admission, Gallery) ab seedha backend (api/\*.php) se database se data lete hain.** Pehle jaisa browser-local (localStorage) data hataya ja chuka hai — ab jo data Admin panel mein save hoga, wahi sab ko dikhega.

---

## 2. Data upload kaise karein (Admin Panel)

Browser mein yeh address kholein:

```
http://localhost/foundation-school/admin.html
```

Admin panel mein **6 tabs** hain:

| #   | Tab                             | Kya karta hai                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| --- | ------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| 1   | **Students**                    | Naya student add karna (naam, class, section, group, roll no, walid ka naam, **student ki photo**). Admission ID khali chhoren to khud ban jati hai (jaise FS2026-001). Photo file chunte hi upload ho jati hai; list mein **Change** button se purane student ki photo bhi badli ja sakti hai. **Kisi bhi student ki photo par click karein** to us ka **pichle 1 month ka test report, attendance aur overall %** ek profile box mein khul jata hai. |
| 2   | **Tests**                       | Naya test/exam banana (naam, subject, class, **section** jaise boys, **group** jaise ICS, total/passing marks). Yahan se **report image** (marks sheet ki photo) bhi upload hoti hai — uploads folder mein save ho kar test se lag jati hai.                                                                                                                                                                                                           |
| 3   | **Result / Test Report Upload** | Class + test chunein → sheet load karein → har student ke marks bharein → **Save**. Marks dobara dalne par purana update ho jata hai (duplicate nahi banta).                                                                                                                                                                                                                                                                                           |
| 4   | **Attendance**                  | Class + tareekh chunein → sheet load karein → har student ke aage **P** (Present), **A** (Absent), **L** (Late) dabayein → **Save**. "Sab Present" button se ek click mein sab P ho jate hain.                                                                                                                                                                                                                                                         |
| 5   | **View Class Result**           | Poori class ka total marks, percentage, grade aur **position list** (1st, 2nd, 3rd...).                                                                                                                                                                                                                                                                                                                                                                |
| 6   | **Attendance Report**           | Class + date range (from → to) se Present/Absent/Late/Leave ginti aur attendance %.                                                                                                                                                                                                                                                                                                                                                                    |

### Upload ka sahi order (yaad rakhein):

```
Students (pehle student hon)  →  Tests (test banayein, image upload karein)  →  Result Upload (marks bharein)  →  Attendance (roz lagayein)
```

### Example: Marks sheet image ke sath test banana (jaise 3rd Term - Class 11 - ICS - boys)

1. **Tests** tab kholein → Test name: `3rd Term Test` → Subject: `english` (har subject ka alag test banayein) → Class: `11` → Section: `boys` → Group: `ICS` → Total: `100` → **Report / Marks Sheet Image** mein sa.png choose karein (image khud upload ho jayegi) → Save.
2. Har subject ke liye dobara se yehi karein (urdu, math, physics, computer, islamiat, uqc) — total marks alag alag dalen.
3. **Result / Test Report Upload** tab mein Class `11` → test chunein (label mein section/group dikhega) → Sheet Load → marks → Save.

**Ready data:** `sql/data_11th_ics_3rdterm.sql` mein Class 11 (ICS, boys) ka poora 3rd Term data pehle se hai — 18 students, 7 subjects, 126 marks rows, image `uploads/sa.png` ke sath. phpMyAdmin se import karein (dobara chalana safe hai).

---

## 3. Backend files kya karti hain?

| File                                                     | Kaam                                                                                                            |
| -------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------- |
| `api/config.php`                                         | Database se connection (host, db name, user, password)                                                          |
| `api/students.php`                                       | Student list, add, detail, photo update, **`profile`** (pichle 1 month ka test report + attendance + overall %) |
| `api/test_reports.php`                                   | Test banana, bulk marks, **`student_report`** (class + roll se report card)                                     |
| `api/results.php`                                        | `class_sheet`, `test_sheet`, `student_result`, **`multi_sheet`** (Result page), **`toppers`** (Gallery)         |
| `api/attendance.php`                                     | Attendance save, list, summary, **`date_report`** (tamam classes ek tareekh ki)                                 |
| `api/upload.php`                                         | Image upload (jpg/png/gif/webp, max 5MB) — uploads folder mein save                                             |
| `api/activity.php`                                       | **Activity log** — website par kya kya hua, dekhne ke liye (admin login zaroori)                                |
| `api/admission.php`                                      | Website par admission form ki entry                                                                             |
| `api/news.php`, `gallery.php`, `staff.php`, `events.php` | Website ke news, gallery, staff, events                                                                         |

### Quick test (browser mein kholein — JSON aana chahiye):

- `http://localhost/foundation-school/api/students.php?action=list`
- `http://localhost/foundation-school/api/results.php?action=multi_sheet&classes=11`
- `http://localhost/foundation-school/api/results.php?action=toppers&limit=3`
- `http://localhost/foundation-school/api/test_reports.php?action=student_report&class=11&roll=1`
- `http://localhost/foundation-school/api/attendance.php?action=date_report&date=2026-10-15`
- `http://localhost/foundation-school/api/upload.php?action=list`

---

## 3.5 Activity Log — website par kya kya hua

Har zaroori kaam **backend mein database mein record** hota hai (`activity_log` table): kisne dekha (IP address), kya dekha (result / test report / attendance), kab, aur kaun sa page. **Frontend mein koi page ya tab nahi bana** — sirf backend record hai. Yeh table `sql/activity_log.sql` se banti hai (nayi database mein `schema.sql` se khud ban jati hai).

**Dekhne ka tareeqa** (browser mein admin login ke baad seedha URL likhein — koi UI nahi):

```
http://localhost/foundation-school/api/activity.php?action=summary
http://localhost/foundation-school/api/activity.php?action=list&limit=200
http://localhost/foundation-school/api/activity.php?action=list&roll=1&class=11
http://localhost/foundation-school/api/activity.php?action=list&from=2026-10-01&to=2026-10-15
http://localhost/foundation-school/api/activity.php?action=list&action_name=report_viewed
http://localhost/foundation-school/api/activity.php?action=student&roll=1
http://localhost/foundation-school/api/activity.php?action=student&ip=127.0.0.1
http://localhost/foundation-school/api/activity.php?action=actions
http://localhost/foundation-school/api/activity.php?action=purge&days=180
```

- **summary** → date range ka khulasa: kul actions, visitors (IP), action-wise ginti, student-wise (roll ke sath), IP-wise, din-wise.
- **list** → raw rows; filters: `from`, `to`, `action_name`, `actor=guest|admin`, `class`, `roll`, `student_id`, `ip`, `q` (naam/detail/IP dhoondhne ke liye), `limit`, `offset`.
- **student** → kisi student/visitor ki poori history (`roll` ya `admission_id` ya `student_id` ya `ip`).
- **purge** → purani rows delete (`days`, default 180).
- Yeh API **sirf admin login ke baad** chalti hai (bina login `401` aata hai). Public pages ke API par asar nahi padta.

**Jo cheezein record hoti hain:** Result page (`result_viewed`, `class_sheet`, `toppers`), Test Report (`report_viewed` — roll ke sath student ka naam + %), Attendance (`attendance_viewed`, `attendance_report_viewed`), Students list (`students_list_viewed`), Admission form (`admission_submitted`), Contact (`contact_message`), aur admin ka kaam (login/logout, `student_added`, `attendance_saved`) — sab par se pata chalta hai kaun **guest** tha aur kaun **admin**.

**Note:** Sirf wahi kaam record hota hai jo API se guzarta hai (backend PHP). Seedha HTML page kholne par (`index.html` waghera) koi record nahi banta — lekin woh pages database se data lene ke liye upar wali APIs call karte hain, is liye activity waise bhi nazar aa jati hai.

---

## 4. Kuch zaroori baatein

- **Grade scale:** A+ = 80% ya zyada, A = 70, B = 60, C = 50, D = 40, warna **F**.
- **Attendance %:** Late (L) ko bhi **present** count kiya jata hai.
- **Duplicate nahi:** Ek student ka ek test mein dobara marks dalne par purana record **update** hota hai. Ek student ki ek tareekh ki attendance bhi update hoti hai.
- **Marks ki limit:** Marks test ke total marks se zyada nahi ho sakte (server khud cut kar deta hai).
- **Image upload:** Sirf JPG/PNG/GIF/WEBP, max 5MB. Images `uploads/` folder mein jati hain. Test ki report image aur **student ki photo** dono isi tarah save hoti hain.
- **Student photo column:** Agar purane database mein `students.image_url` column nahi hai to `sql/upgrade_student_photo.sql` import karein.
- **Section / Group:** Test aur student dono par section (boys/girls/A/B) aur group (ICS, Pre-Medical...) ka field hai — college classes ke liye.
- **Abhi data maujood hai:** Class 11 (ICS, boys) ka 3rd Term — 18 students, 7 subjects, image `uploads/sa.png`.
- **Admin panel par abhi LOGIN nahi hai.** Agar website publicly internet par jayegi, to login (username/password) zaroor lagwayein — warna koi bhi data change kar sakta hai. Database mein `users` table aur admin ID pehle se bani hui hai (username: `admin`, password: `password`).

---

## 5. Masla aa jaye to check karein

| Problem                                                       | Solution                                                                                                                         |
| ------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------- |
| Sheet load nahi hoti / "Failed to fetch"                      | XAMPP mein Apache + MySQL chalu hain?                                                                                            |
| Database error                                                | `phpMyAdmin` mein database `foundation_school_chanari` hai? `sql/schema.sql` import kiya?                                        |
| `api/config.php` error                                        | Database name, user, password sahi hain? (XAMPP: root / khali password)                                                          |
| Marks save nahi hote                                          | Pehle **Tests** tab mein test bana hai? Student add hua hai?                                                                     |
| Attendance table missing error                                | `sql/upgrade_v2.sql` import karein                                                                                               |
| Image upload fail                                             | `uploads/` folder mein write permission ho? Image 5MB se chhoti ho?                                                              |
| Result / Test Report / Attendance page khali ya error dikhaye | Woh pages ab database se data lete hain — pehle Admin panel mein students + tests + marks save karein, phir public page kholein. |
