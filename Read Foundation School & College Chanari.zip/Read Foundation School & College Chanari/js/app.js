/* Read Foundation School Chanari - shared layout */

const SCHOOL = {
  name: "Read Foundation School Chanari",
  tagline: "Nursery to 12th Class",
  phone: "+92 300 0000000",
  email: "info@readfoundationschool.edu.pk",
  address: "Chanari, Pakistan",
  timings: "Mon - Sat: 8:00 AM - 2:00 PM"
};

const NAV = [
  { href: "index.html", label: "Home" },
  { href: "about.html", label: "About" },
  { href: "teachers.html", label: "Teachers" },
  { href: "content.html", label: "Content" },
  { href: "gallery.html", label: "Gallery" },
  { href: "test-report.html", label: "Test Report" },
  { href: "homework.html", label: "Homework" },
  { href: "admission.html", label: "Admission" },
  { href: "result.html", label: "Result" },
  { href: "attendance.html", label: "Daily Attendance" }
];

/* ---------- Notifications (navbar bell) ---------- */
const NOTIF_SEEN_KEY = "rf_notifications_seen";

const NOTIF_ICONS = {
  general: "&#128276;",
  academic: "&#128218;",
  event: "&#128197;",
  achievement: "&#127942;",
  holiday: "&#127881;"
};

function notifEscape(value) {
  return String(value == null ? "" : value).replace(/[&<>"']/g, function (ch) {
    return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch];
  });
}

function notifDate(value) {
  if (!value) return null;
  const d = new Date(String(value).replace(" ", "T"));
  return isNaN(d.getTime()) ? null : d;
}

function notifTimeAgo(value) {
  const d = notifDate(value);
  if (!d) return "";
  const diff = Math.max(0, Date.now() - d.getTime());
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "Just now";
  if (mins < 60) return mins + "m ago";
  const hours = Math.floor(mins / 60);
  if (hours < 24) return hours + "h ago";
  const days = Math.floor(hours / 24);
  if (days < 7) return days + "d ago";
  return d.toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" });
}

function notifSeenAt() {
  try {
    return Number(localStorage.getItem(NOTIF_SEEN_KEY) || 0);
  } catch (e) {
    return 0;
  }
}

function markNotificationsSeen() {
  try {
    localStorage.setItem(NOTIF_SEEN_KEY, String(Date.now()));
  } catch (e) {
    /* ignore if localStorage is not available */
  }
}

/* ---------- Cat meow + animation on navbar click ---------- */
let meowCtx = null;

function playMeow() {
  try {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    if (!meowCtx) meowCtx = new AC();
    if (meowCtx.state === "suspended") meowCtx.resume();

    const now = meowCtx.currentTime;

    const master = meowCtx.createGain();
    master.gain.setValueAtTime(0.0001, now);
    master.gain.exponentialRampToValueAtTime(0.22, now + 0.06);
    master.gain.exponentialRampToValueAtTime(0.16, now + 0.22);
    master.gain.exponentialRampToValueAtTime(0.0001, now + 0.55);
    master.connect(meowCtx.destination);

    const filter = meowCtx.createBiquadFilter();
    filter.type = "bandpass";
    filter.frequency.setValueAtTime(1400, now);
    filter.frequency.exponentialRampToValueAtTime(900, now + 0.45);
    filter.Q.value = 3;
    filter.connect(master);

    const osc = meowCtx.createOscillator();
    osc.type = "sawtooth";
    osc.frequency.setValueAtTime(650, now);
    osc.frequency.exponentialRampToValueAtTime(880, now + 0.12);
    osc.frequency.exponentialRampToValueAtTime(420, now + 0.5);

    const lfo = meowCtx.createOscillator();
    const lfoGain = meowCtx.createGain();
    lfo.frequency.value = 22;
    lfoGain.gain.value = 35;
    lfo.connect(lfoGain);
    lfoGain.connect(osc.frequency);

    osc.connect(filter);
    osc.start(now);
    lfo.start(now);
    osc.stop(now + 0.6);
    lfo.stop(now + 0.6);
  } catch (e) {
    /* ignore if sound is not supported */
  }
}

function showCat(element) {
  if (!element) return;
  const rect = element.getBoundingClientRect();
  const cat = document.createElement("div");
  cat.className = "cat-runner";
  cat.innerHTML = '<span class="cat-face">&#128049;</span><span class="meow-bubble">Meow!</span>';
  cat.style.left = Math.max(8, rect.left) + "px";
  cat.style.top = (rect.top + rect.height / 2 - 20) + "px";
  document.body.appendChild(cat);
  setTimeout(function () { cat.remove(); }, 1200);
}

function setupNavCat(nav) {
  let busy = false;

  function trigger(element) {
    playMeow();
    showCat(element);
    element.classList.add("nav-clicked");
    setTimeout(function () { element.classList.remove("nav-clicked"); }, 450);
  }

  nav.addEventListener("click", function (event) {
    const link = event.target.closest("a");
    if (!link) return;
    if (link.target === "_blank" || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;

    const href = link.getAttribute("href");
    if (!href || href.charAt(0) === "#" || href.indexOf("javascript:") === 0) return;

    event.preventDefault();
    if (busy) return;
    busy = true;

    trigger(link);
    setTimeout(function () { window.location.href = href; }, 700);
  });

  const bell = nav.querySelector(".notif-btn");
  if (bell) {
    bell.addEventListener("click", function () { trigger(bell); });
  }

  const toggle = nav.querySelector(".nav-toggle");
  if (toggle) {
    toggle.addEventListener("click", function () { trigger(toggle); });
  }
}

function setupNotifications() {
  const box = document.getElementById("navNotify");
  if (!box) return;

  const btn = box.querySelector(".notif-btn");
  const panel = box.querySelector(".notif-panel");
  const badge = box.querySelector(".notif-badge");
  const list = box.querySelector(".notif-list");
  let items = [];

  function updateBadge() {
    const seen = notifSeenAt();
    const count = items.filter(function (n) {
      const d = notifDate(n.published_at);
      return d && d.getTime() > seen;
    }).length;

    if (count > 0) {
      badge.textContent = count > 9 ? "9+" : String(count);
      badge.hidden = false;
    } else {
      badge.hidden = true;
    }
  }

  function renderList() {
    if (!items.length) {
      list.innerHTML = '<p class="notif-empty">There are no notifications yet.</p>';
      return;
    }
    list.innerHTML = items.map(function (n) {
      const category = String(n.category || "general").toLowerCase();
      const icon = NOTIF_ICONS[category] || NOTIF_ICONS.general;
      return `<a class="notif-item" href="notifications.html">
        <span class="notif-ico">${icon}</span>
        <span class="notif-body">
          <span class="notif-title">${notifEscape(n.title || "Notification")}</span>
          <span class="notif-meta">${notifEscape(category)} &bull; ${notifEscape(notifTimeAgo(n.published_at))}</span>
        </span>
      </a>`;
    }).join("");
  }

  function closePanel() {
    panel.hidden = true;
    btn.setAttribute("aria-expanded", "false");
  }

  btn.addEventListener("click", function (event) {
    event.stopPropagation();
    const willOpen = panel.hidden;
    panel.hidden = !willOpen;
    btn.setAttribute("aria-expanded", String(willOpen));
    if (willOpen) {
      markNotificationsSeen();
      updateBadge();
    }
  });

  document.addEventListener("click", function (event) {
    if (!box.contains(event.target)) closePanel();
  });

  document.addEventListener("keydown", function (event) {
    if (event.key === "Escape") closePanel();
  });

  fetch("api/news.php", { headers: { Accept: "application/json" } })
    .then(function (res) {
      if (!res.ok) throw new Error("News API error");
      return res.json();
    })
    .then(function (data) {
      items = (Array.isArray(data) ? data : [])
        .filter(function (n) { return !n.status || n.status === "published"; })
        .slice(0, 6);
      renderList();
      updateBadge();
    })
    .catch(function () {
      list.innerHTML = '<p class="notif-empty">Notifications could not be loaded. Please try again later.</p>';
    });
}

function renderLayout() {
  const page = document.body.dataset.page || "";

  const topbar = document.getElementById("site-topbar");
  if (topbar) {
    topbar.className = "topbar";
    topbar.innerHTML = `<div class="wrap">
      <span>&#9742; ${SCHOOL.phone}</span>
      <span>&#9993; ${SCHOOL.email}</span>
      <span>&#128337; ${SCHOOL.timings}</span>
    </div>`;
  }

  const header = document.getElementById("site-header");
  if (header) {
    header.className = "site";
    header.innerHTML = `<div class="wrap">
      <div class="logo">RF</div>
      <div class="brand">
        <h1>${SCHOOL.name}</h1>
        <p>${SCHOOL.tagline} &bull; Knowledge, Character, Service</p>
      </div>
    </div>`;
  }

  const nav = document.getElementById("site-nav");
  if (nav) {
    nav.className = "main";
    const links = NAV.map(n =>
      `<a href="${n.href}"${n.href === page ? ' class="active"' : ""}>${n.label}</a>`
    ).join("");
    nav.innerHTML = `<button class="nav-toggle" onclick="document.getElementById('site-nav').classList.toggle('open')">&#9776; Menu</button>
      <div class="wrap">
        <div class="nav-links">${links}</div>
        <div class="nav-notify" id="navNotify">
          <button type="button" class="notif-btn" aria-label="Notifications" aria-expanded="false" title="Notifications">
            <span class="notif-bell">&#128276;</span>
            <span class="notif-label">Notifications</span>
            <span class="notif-badge" hidden>0</span>
          </button>
          <div class="notif-panel" hidden>
            <div class="notif-head"><b>Notifications</b><a href="notifications.html">View all</a></div>
            <div class="notif-list"><p class="notif-empty">Loading...</p></div>
          </div>
        </div>
        <a class="nav-login" href="login.html" title="Admin Login">Login</a>
      </div>`;
    setupNotifications();
    setupNavCat(nav);
  }

  const footer = document.getElementById("site-footer");
  if (footer) {
    footer.className = "site";
    footer.innerHTML = `<div class="wrap">
      <div>
        <h4>${SCHOOL.name}</h4>
        <p>A caring institution from Nursery to 12th class, committed to quality education and strong values.</p>
      </div>
      <div>
        <h4>Quick Links</h4>
        <ul>
          <li><a href="notifications.html">Notifications</a></li>
          <li><a href="homework.html">Homework &amp; Tests</a></li>
          <li><a href="admission.html">Admission</a></li>
          <li><a href="test-report.html">Test Report</a></li>
          <li><a href="result.html">Result</a></li>
          <li><a href="attendance.html">Daily Attendance</a></li>
        </ul>
      </div>
      <div>
        <h4>Contact</h4>
        <ul>
          <li>${SCHOOL.address}</li>
          <li>${SCHOOL.phone}</li>
          <li>${SCHOOL.email}</li>
        </ul>
      </div>
    </div>
    <div class="wrap"><div class="copy">&copy; ${new Date().getFullYear()} ${SCHOOL.name}. All rights reserved.</div></div>`;
  }
}

document.addEventListener("DOMContentLoaded", renderLayout);

/* ---------- Banner auto slideshow (no buttons, chalta rehta hai) ---------- */
function startBannerSlideshow() {
  const slides = document.querySelectorAll(".banner-slider .slide");
  if (slides.length < 2) return;

  let current = 0;
  setInterval(function () {
    slides[current].classList.remove("active");
    current = (current + 1) % slides.length;
    slides[current].classList.add("active");
  }, 4000);
}

document.addEventListener("DOMContentLoaded", startBannerSlideshow);
