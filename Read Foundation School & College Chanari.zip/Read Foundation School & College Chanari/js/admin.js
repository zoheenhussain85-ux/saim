/* Admin Panel - Read Foundation School Chanari
   All data entry happens here: students, tests, results (marks), attendance.
   This file makes API calls to: api/students.php, api/test_reports.php,
   api/results.php, api/attendance.php */

const CLASSES = ["Nursery", "KG", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"];

/* Har class ka fixed class number (Nursery = FS101 ... Class 12 = FS114).
   Number yahan se change kar sakte hain. */
const CLASS_NUMBERS = {
  "Nursery": "FS101",
  "KG": "FS102",
  "1": "FS103",
  "2": "FS104",
  "3": "FS105",
  "4": "FS106",
  "5": "FS107",
  "6": "FS108",
  "7": "FS109",
  "8": "FS110",
  "9": "FS111",
  "10": "FS112",
  "11": "FS113",
  "12": "FS114"
};

function classNumber(cls) {
  return CLASS_NUMBERS[String(cls)] || "";
}

function syncStuClassNo() {
  const input = qs("stuClassNo");
  if (input) input.value = classNumber(qs("stuClass").value);
}

function qs(id) { return document.getElementById(id); }

function showMsg(el, text, ok) {
  el.textContent = text;
  el.className = "msg " + (ok ? "ok" : "err");
}

function clearMsg(el) { el.className = "msg"; el.textContent = ""; }

function esc(value) {
  return String(value == null ? "" : value).replace(/[&<>"']/g, function (ch) {
    return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch];
  });
}

async function api(url, options) {
  const res = await fetch(url, options);
  const data = await res.json();
  if (!res.ok) throw new Error(data.message || "Server error");
  return data;
}

function postForm(url, obj) {
  const fd = new FormData();
  Object.keys(obj).forEach(function (k) {
    if (obj[k] !== undefined && obj[k] !== null) fd.append(k, obj[k]);
  });
  return api(url, { method: "POST", body: fd });
}

function postJson(url, obj) {
  return api(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(obj)
  });
}

// Uploads the photo to the backend (uploads folder) and returns its URL.
async function uploadPhoto(file) {
  const fd = new FormData();
  fd.append("image", file);
  const data = await api("api/upload.php?action=upload", { method: "POST", body: fd });
  return data.url;
}

function fillClasses(sel) {
  sel.innerHTML = "";
  CLASSES.forEach(function (c) {
    const o = document.createElement("option");
    o.value = c;
    o.textContent = (c === "Nursery" || c === "KG") ? c : "Class " + c;
    sel.appendChild(o);
  });
}

/* Class dropdown with class number + "All Classes" option (1 month sheet) */
function fillClassFilter(sel) {
  sel.innerHTML = '<option value="">All Classes</option>';
  CLASSES.forEach(function (c) {
    const o = document.createElement("option");
    o.value = c;
    o.textContent = ((c === "Nursery" || c === "KG") ? c : "Class " + c) + " (" + classNumber(c) + ")";
    sel.appendChild(o);
  });
}

function today() { return new Date().toISOString().slice(0, 10); }

/* ---------- Tabs ---------- */
document.querySelectorAll(".tabs button").forEach(function (btn) {
  btn.addEventListener("click", function () {
    document.querySelectorAll(".tabs button").forEach(function (b) { b.classList.remove("active"); });
    document.querySelectorAll(".tab-panel").forEach(function (p) { p.classList.remove("active"); });
    btn.classList.add("active");
    qs("tab-" + btn.dataset.tab).classList.add("active");
  });
});

/* ---------- 1. Students ---------- */
function studentPhotoCell(s) {
  const thumb = s.image_url
    ? '<img src="' + esc(s.image_url) + '" alt="" class="stu-thumb" />'
    : '<div class="stu-thumb empty">NO PHOTO</div>';
  return '<button type="button" class="photo-open" data-id="' + esc(s.id) + '" title="View 1 month report and attendance">' + thumb + "</button>" +
    '<button type="button" class="photo-edit" data-id="' + esc(s.id) + '">Change</button>' +
    '<input type="file" class="photo-edit-input hidden" data-id="' + esc(s.id) + '" accept="image/*" />';
}

async function loadStudentsList() {
  stuRows = await api("api/students.php?action=list");
  renderStudentsList();
}

let stuRows = [];

function studentMatchesSearch(s, q) {
  if (!q) return true;
  const classNo = classNumber(s.current_class).toLowerCase();
  const compact = q.replace(/\s+/g, "");
  // Class number likha ho (FS101) to sirf usi class ke students.
  if (compact.indexOf("fs") === 0) return classNo.indexOf(compact) === 0;
  const classText = ((s.current_class === "Nursery" || s.current_class === "KG")
    ? String(s.current_class)
    : "Class " + s.current_class).toLowerCase();
  return [classNo, classText, s.admission_id, s.full_name, s.roll_no]
    .join(" ").toLowerCase().indexOf(q) >= 0;
}

function renderStudentsList() {
  const q = (qs("stuSearch").value || "").trim().toLowerCase();
  const rows = stuRows.filter(function (s) { return studentMatchesSearch(s, q); });

  const info = qs("stuFilterInfo");
  if (info) {
    info.textContent = q
      ? "Showing " + rows.length + " of " + stuRows.length + " students for \"" + q + "\"."
      : stuRows.length + " student" + (stuRows.length === 1 ? "" : "s") + " in database.";
  }

  qs("stuTableBody").innerHTML = rows.map(function (s) {
    return "<tr>" +
      '<td class="num">' + studentPhotoCell(s) + "</td>" +
      "<td>" + esc(s.admission_id) + "</td>" +
      "<td>" + esc(s.full_name) + "</td>" +
      "<td>" + esc(s.current_class) + "</td>" +
      "<td><b>" + esc(classNumber(s.current_class) || "-") + "</b></td>" +
      "<td>" + esc(s.section || "-") + "</td>" +
      "<td>" + esc(s.student_group || "-") + "</td>" +
      "<td>" + esc(s.roll_no || "-") + "</td>" +
      "<td>" + esc(s.parent_name || "-") + "</td>" +
      "</tr>";
  }).join("") || '<tr><td colspan="9">' +
    (q ? "No student found for this class number / search." : "No students yet.") + "</td></tr>";
}

qs("stuSearch").addEventListener("input", renderStudentsList);

// New student photo: uploaded as soon as the file is selected
let stuPhotoUploading = false;

qs("stuPhoto").addEventListener("change", async function () {
  const file = this.files[0];
  const wrap = qs("stuPhotoWrap");
  const info = qs("stuPhotoInfo");
  const preview = qs("stuPhotoPreview");
  if (!file) {
    qs("stuImageUrl").value = "";
    wrap.classList.add("hidden");
    preview.removeAttribute("src");
    return;
  }
  wrap.classList.remove("hidden");
  info.textContent = "Uploading photo...";
  stuPhotoUploading = true;
  try {
    const url = await uploadPhoto(file);
    qs("stuImageUrl").value = url;
    preview.src = url;
    info.textContent = "Photo saved.";
  } catch (err) {
    qs("stuImageUrl").value = "";
    preview.removeAttribute("src");
    info.textContent = "Photo upload failed: " + err.message;
  } finally {
    stuPhotoUploading = false;
  }
});

// Click photo: student's 1 month report + attendance
// Click Change button: open file picker to replace the photo
qs("stuTableBody").addEventListener("click", function (e) {
  const openBtn = e.target.closest(".photo-open");
  if (openBtn) {
    openStudentProfile(openBtn.dataset.id);
    return;
  }
  const editBtn = e.target.closest(".photo-edit");
  if (!editBtn) return;
  const input = editBtn.parentElement.querySelector(".photo-edit-input");
  if (input) input.click();
});

qs("stuTableBody").addEventListener("change", async function (e) {
  const input = e.target.closest(".photo-edit-input");
  if (!input || !input.files[0]) return;
  const msg = qs("stuMsg");
  clearMsg(msg);
  try {
    const url = await uploadPhoto(input.files[0]);
    const data = await postForm("api/students.php?action=update_photo", {
      id: input.dataset.id,
      image_url: url
    });
    showMsg(msg, data.message, data.success);
    if (data.success) loadStudentsList();
  } catch (err) {
    showMsg(msg, "Photo update failed: " + err.message, false);
  }
});

// Show photo + Admission ID after saving
function showSavedStudent(id, name, admissionId, photoUrl, classLevel) {
  const box = qs("stuSaved");
  const photo = photoUrl
    ? '<img src="' + esc(photoUrl) + '" alt="Student photo" />'
    : '<div class="no-img">NO PHOTO</div>';
  box.innerHTML =
    '<button type="button" class="photo-open" data-id="' + esc(id) + '" title="View 1 month report and attendance">' + photo + "</button>" +
    "<div><b>" + esc(name) + "</b><br>" +
    "Admission ID: <b>" + esc(admissionId) + "</b><br>" +
    "Class No: <b>" + esc(classNumber(classLevel) || "-") + "</b><br>" +
    '<span class="note" style="margin:0;">Click the photo &rarr; 1 month report + attendance</span></div>';
  box.classList.remove("hidden");
}

/* ---------- Student profile modal (1 month report + attendance) ---------- */
function closeStudentModal() {
  qs("studentModal").classList.add("hidden");
  document.body.style.overflow = "";
}

async function openStudentProfile(id) {
  const modal = qs("studentModal");
  const body = qs("stuModalBody");
  body.innerHTML = '<p class="note">Loading student data...</p>';
  modal.classList.remove("hidden");
  document.body.style.overflow = "hidden";
  try {
    const data = await api("api/students.php?action=profile&id=" + encodeURIComponent(id));
    if (!data.success) throw new Error(data.message || "Profile did not load.");
    renderStudentProfile(data);
  } catch (err) {
    body.innerHTML = '<p class="msg err" style="display:block;">' + esc(err.message) + "</p>";
  }
}

function renderStudentProfile(data) {
  const s = data.student;
  const range = data.range;
  const ts = data.tests_summary;
  const attSum = data.attendance_summary;
  const overall = data.overall || {};

  const photo = s.image_url
    ? '<img src="' + esc(s.image_url) + '" alt="Student photo" />'
    : '<div class="profile-noimg">NO PHOTO</div>';

  const info = [
    "Admission ID: <b>" + esc(s.admission_id) + "</b>",
    "Class: <b>" + esc(s.current_class) + "</b>",
    "Class No: <b>" + esc(classNumber(s.current_class) || "-") + "</b>",
    s.section ? "Section: <b>" + esc(s.section) + "</b>" : "",
    s.student_group ? "Group: <b>" + esc(s.student_group) + "</b>" : "",
    s.roll_no ? "Roll No: <b>" + esc(s.roll_no) + "</b>" : "",
    s.parent_name ? "Father: <b>" + esc(s.parent_name) + "</b>" : "",
    s.phone ? "Phone: <b>" + esc(s.phone) + "</b>" : "",
    s.date_of_birth ? "DOB: <b>" + esc(s.date_of_birth) + "</b>" : ""
  ].filter(Boolean).join(" &nbsp;|&nbsp; ");

  const statusLabel = {
    present: '<span class="status-pill status-present">Present</span>',
    absent: '<span class="status-pill status-absent">Absent</span>',
    late: '<span class="status-pill status-late">Late</span>',
    leave: '<span class="status-pill status-leave">Leave</span>'
  };

  const testRows = data.tests.map(function (t) {
    return "<tr>" +
      "<td>" + esc(t.test_date || (t.report_date || "").slice(0, 10)) + "</td>" +
      "<td>" + esc(t.test_name) + "</td>" +
      "<td>" + esc(t.subject) + "</td>" +
      '<td class="num">' + esc(t.marks_obtained) + " / " + esc(t.total_marks) + "</td>" +
      '<td class="num"><b>' + Number(t.percentage).toFixed(2) + "%</b></td>" +
      '<td class="num"><b>' + esc(t.grade) + "</b></td>" +
      "<td>" + esc(t.remarks || "-") + "</td>" +
      "</tr>";
  }).join("") || '<tr><td colspan="7">No test reports in the last 1 month.</td></tr>';

  const attRows = data.attendance.map(function (a) {
    return "<tr>" +
      "<td>" + esc(a.att_date) + "</td>" +
      "<td>" + (statusLabel[a.status] || esc(a.status)) + "</td>" +
      "<td>" + esc(a.remarks || "-") + "</td>" +
      "</tr>";
  }).join("") || '<tr><td colspan="3">No attendance in the last 1 month.</td></tr>';

  qs("stuModalBody").innerHTML =
    '<div class="profile-head">' + photo +
      "<div><h3>" + esc(s.full_name) + "</h3>" +
      '<p>' + info + "</p></div>" +
    "</div>" +
    '<div class="stat-row">' +
      '<div class="stat"><span>1 Month Tests</span><b>' + ts.count + "</b></div>" +
      '<div class="stat"><span>1 Month Test %</span><b>' + Number(ts.percentage).toFixed(2) + "%</b></div>" +
      '<div class="stat"><span>1 Month Attendance</span><b>' + attSum.percentage + "%</b></div>" +
      '<div class="stat"><span>Overall Test %</span><b>' + Number(overall.test_percentage || 0).toFixed(2) + "%</b></div>" +
      '<div class="stat"><span>Overall Attendance</span><b>' + (overall.attendance_percentage || 0) + "%</b></div>" +
    "</div>" +
    '<div class="profile-section">' +
      "<h4>Test Report - Last 1 Month</h4>" +
      '<p class="note">' + esc(range.from) + " to " + esc(range.to) +
        " &nbsp;|&nbsp; Total: <b>" + ts.obtained + " / " + ts.total + "</b>" +
        " &nbsp;|&nbsp; Grade: <b>" + esc(ts.grade) + "</b>" +
        " &nbsp;|&nbsp; Overall: <b>" + (overall.tests || 0) + " tests</b></p>" +
      '<div class="table-scroll"><table class="sheet"><thead><tr>' +
        "<th>Date</th><th>Test</th><th>Subject</th><th class=\"num\">Marks</th><th class=\"num\">%</th><th class=\"num\">Grade</th><th>Remarks</th>" +
      "</tr></thead><tbody>" + testRows + "</tbody></table></div>" +
    "</div>" +
    '<div class="profile-section">' +
      "<h4>Attendance - Last 1 Month</h4>" +
      '<p class="note">Present: <b>' + attSum.present + "</b> &nbsp;|&nbsp; Absent: <b>" + attSum.absent +
        "</b> &nbsp;|&nbsp; Late: <b>" + attSum.late + "</b> &nbsp;|&nbsp; Leave: <b>" + attSum.leave +
        "</b> &nbsp;|&nbsp; Total: <b>" + attSum.total + "</b></p>" +
      '<div class="table-scroll"><table class="sheet"><thead><tr>' +
        "<th>Date</th><th>Status</th><th>Remarks</th>" +
      "</tr></thead><tbody>" + attRows + "</tbody></table></div>" +
    "</div>";
}

qs("stuModalClose").addEventListener("click", closeStudentModal);
qs("studentModal").addEventListener("click", function (e) {
  if (e.target === qs("studentModal")) closeStudentModal();
});
document.addEventListener("keydown", function (e) {
  if (e.key === "Escape") closeStudentModal();
});
qs("stuSaved").addEventListener("click", function (e) {
  const btn = e.target.closest(".photo-open");
  if (btn) openStudentProfile(btn.dataset.id);
});

qs("studentForm").addEventListener("submit", async function (e) {
  e.preventDefault();
  const msg = qs("stuMsg");
  clearMsg(msg);
  qs("stuSaved").classList.add("hidden");
  if (stuPhotoUploading) {
    showMsg(msg, "Photo is uploading, please wait.", false);
    return;
  }
  const name = qs("stuName").value.trim();
  const photoUrl = qs("stuImageUrl").value;
  try {
    const data = await postForm("api/students.php?action=add", {
      admission_id: qs("stuAdm").value.trim(),
      full_name: name,
      gender: qs("stuGender").value,
      current_class: qs("stuClass").value,
      section: qs("stuSection").value.trim(),
      student_group: qs("stuGroup").value.trim(),
      roll_no: qs("stuRoll").value.trim(),
      parent_name: qs("stuParent").value.trim(),
      date_of_birth: qs("stuDob").value,
      image_url: photoUrl
    });
    showMsg(msg, data.message, data.success);
    if (data.success) {
      showSavedStudent(data.id, name, data.admission_id, photoUrl, qs("stuClass").value);
      e.target.reset();
      qs("stuImageUrl").value = "";
      qs("stuPhotoWrap").classList.add("hidden");
      qs("stuPhotoPreview").removeAttribute("src");
      fillClasses(qs("stuClass"));
      syncStuClassNo();
      loadStudentsList();
    }
  } catch (err) {
    showMsg(msg, err.message, false);
  }
});

/* ---------- 2. Tests ---------- */
qs("tImage").addEventListener("change", async function () {
  const file = this.files[0];
  const info = qs("tImageInfo");
  if (!file) { qs("tImageUrl").value = ""; info.style.display = "none"; return; }
  info.style.display = "block";
  info.textContent = "Uploading image...";
  const fd = new FormData();
  fd.append("image", file);
  try {
    const data = await api("api/upload.php?action=upload", { method: "POST", body: fd });
    qs("tImageUrl").value = data.url;
    info.textContent = "Image saved to the backend: " + data.url;
  } catch (err) {
    qs("tImageUrl").value = "";
    info.textContent = "Image upload failed: " + err.message;
  }
});

qs("testForm").addEventListener("submit", async function (e) {
  e.preventDefault();
  const msg = qs("testMsg");
  clearMsg(msg);
  try {
    const data = await postForm("api/test_reports.php?action=add_test", {
      test_name: qs("tName").value.trim(),
      subject: qs("tSubject").value.trim(),
      class_level: qs("tClass").value,
      section: qs("tSection").value.trim(),
      group_name: qs("tGroup").value.trim(),
      image_url: qs("tImageUrl").value,
      total_marks: qs("tTotal").value,
      passing_marks: qs("tPass").value,
      test_date: qs("tDate").value,
      description: qs("tDesc").value.trim()
    });
    showMsg(msg, data.message, data.success);
    if (data.success) {
      e.target.reset();
      qs("tTotal").value = 100;
      qs("tPass").value = 33;
      qs("tDate").value = today();
      qs("tImageUrl").value = "";
      qs("tImageInfo").style.display = "none";
      loadTestsForUpload();
    }
  } catch (err) {
    showMsg(msg, err.message, false);
  }
});

/* ---------- 3. Result / Test Report Upload ---------- */
async function loadTestsForUpload() {
  const sel = qs("ruTest");
  const cls = qs("ruClass").value;
  sel.innerHTML = '<option value="">-- Select test --</option>';
  if (!cls) return;
  const tests = await api("api/test_reports.php?action=get_tests&class=" + encodeURIComponent(cls));
  tests.forEach(function (t) {
    const o = document.createElement("option");
    o.value = t.id;
    let label = t.test_name + " — " + t.subject + " (" + t.total_marks + " marks)";
    if (t.section) label += " | Sec: " + t.section;
    if (t.group_name) label += " | Group: " + t.group_name;
    o.textContent = label;
    sel.appendChild(o);
  });
  if (!tests.length) sel.innerHTML = '<option value="">-- No tests for this class (create one in the Tests tab first) --</option>';
}

let ruStudents = [];

qs("ruLoad").addEventListener("click", async function () {
  const msg = qs("ruMsg");
  clearMsg(msg);
  const testId = qs("ruTest").value;
  if (!testId) { showMsg(msg, "Please select a test first.", false); return; }
  try {
    const sheet = await api("api/results.php?action=test_sheet&test_id=" + testId);
    ruStudents = sheet.rows;
    const total = Number(sheet.test.total_marks);
    qs("ruTotal").textContent = total;
    qs("ruBody").innerHTML = ruStudents.map(function (s, i) {
      const marks = s.marks_obtained == null ? "" : esc(s.marks_obtained);
      return "<tr>" +
        "<td>" + esc(s.roll_no || "-") + "</td>" +
        "<td>" + esc(s.full_name) + "</td>" +
        '<td class="num"><input type="number" min="0" max="' + total + '" step="1" value="' + marks + '" data-i="' + i + '" class="ru-marks" /></td>' +
        '<td><input type="text" value="' + esc(s.remarks || "") + '" data-i="' + i + '" class="ru-remarks" placeholder="Remarks" /></td>' +
        "</tr>";
    }).join("") || '<tr><td colspan="4">There are no students in this class. Add a student in the Students tab first.</td></tr>';
    qs("ruSheet").classList.remove("hidden");
  } catch (err) {
    showMsg(msg, err.message, false);
  }
});

qs("ruSave").addEventListener("click", async function () {
  const msg = qs("ruMsg");
  clearMsg(msg);
  const testId = qs("ruTest").value;
  if (!testId || !ruStudents.length) { showMsg(msg, "Please load the sheet first.", false); return; }

  const reports = [];
  document.querySelectorAll(".ru-marks").forEach(function (inp) {
    if (inp.value === "") return;
    const i = inp.dataset.i;
    const remarksEl = document.querySelector('.ru-remarks[data-i="' + i + '"]');
    reports.push({
      student_id: Number(ruStudents[i].student_id),
      marks_obtained: Number(inp.value),
      remarks: remarksEl ? remarksEl.value.trim() : ""
    });
  });
  if (!reports.length) { showMsg(msg, "No student marks have been entered.", false); return; }

  try {
    const data = await postJson("api/test_reports.php?action=bulk_add", {
      test_id: Number(testId),
      reports: reports
    });
    showMsg(msg, data.message + " Open the 'View Class Result' tab for positions.", data.success);
  } catch (err) {
    showMsg(msg, err.message, false);
  }
});

/* ---------- 4. Attendance ---------- */
let attStudents = [];
const attStatus = {};

function renderAttSheet() {
  qs("attBody").innerHTML = attStudents.map(function (s, i) {
    const st = attStatus[s.student_id] || "present";
    return "<tr>" +
      "<td>" + esc(s.roll_no || "-") + "</td>" +
      "<td>" + esc(s.full_name) + "</td>" +
      "<td>" + esc(s.admission_id) + "</td>" +
      '<td><div class="status-btns" data-i="' + i + '">' +
        '<button type="button" data-st="present" class="' + (st === "present" ? "sel-present" : "") + '">P</button>' +
        '<button type="button" data-st="absent" class="' + (st === "absent" ? "sel-absent" : "") + '">A</button>' +
        '<button type="button" data-st="late" class="' + (st === "late" ? "sel-late" : "") + '">L</button>' +
      "</div></td>" +
      "</tr>";
  }).join("") || '<tr><td colspan="4">There are no students in this class.</td></tr>';
}

qs("attBody").addEventListener("click", function (e) {
  const btn = e.target.closest("button[data-st]");
  if (!btn) return;
  const wrap = btn.closest(".status-btns");
  const student = attStudents[Number(wrap.dataset.i)];
  if (!student) return;
  attStatus[student.student_id] = btn.dataset.st;
  wrap.querySelectorAll("button").forEach(function (b) { b.className = ""; });
  btn.className = btn.dataset.st === "present" ? "sel-present" : btn.dataset.st === "absent" ? "sel-absent" : "sel-late";
});

qs("attAllP").addEventListener("click", function () {
  attStudents.forEach(function (s) { attStatus[s.student_id] = "present"; });
  renderAttSheet();
});

qs("attLoad").addEventListener("click", async function () {
  const msg = qs("attMsg");
  clearMsg(msg);
  const cls = qs("attClass").value;
  const date = qs("attDate").value;
  if (!cls || !date) { showMsg(msg, "Both class and date are required.", false); return; }
  try {
    const students = await api("api/students.php?action=list&class=" + encodeURIComponent(cls));
    const saved = await api("api/attendance.php?action=list&class=" + encodeURIComponent(cls) + "&date=" + date);
    attStudents = students;
    Object.keys(attStatus).forEach(function (k) { delete attStatus[k]; });
    attStudents.forEach(function (s) { attStatus[s.student_id] = "present"; });
    saved.forEach(function (r) { attStatus[r.student_id] = r.status; });
    renderAttSheet();
    qs("attSheet").classList.remove("hidden");
    showMsg(msg, attStudents.length + " students' sheet loaded.", true);
  } catch (err) {
    showMsg(msg, err.message, false);
  }
});

qs("attSave").addEventListener("click", async function () {
  const msg = qs("attMsg");
  clearMsg(msg);
  const date = qs("attDate").value;
  if (!attStudents.length || !date) { showMsg(msg, "Please load the sheet first.", false); return; }
  const records = attStudents.map(function (s) {
    return { student_id: s.student_id, status: attStatus[s.student_id] || "present" };
  });
  try {
    const data = await postJson("api/attendance.php?action=save", { date: date, records: records });
    showMsg(msg, data.message, data.success);
  } catch (err) {
    showMsg(msg, err.message, false);
  }
});

/* ---------- 5. View Class Result ---------- */
qs("vrLoad").addEventListener("click", async function () {
  const msg = qs("vrMsg");
  clearMsg(msg);
  const cls = qs("vrClass").value;
  if (!cls) { showMsg(msg, "Please select a class.", false); return; }
  try {
    const data = await api("api/results.php?action=class_sheet&class=" + encodeURIComponent(cls));
    qs("vrBody").innerHTML = data.rows.map(function (r) {
      return "<tr>" +
        '<td class="num"><b>' + r.position + "</b></td>" +
        "<td>" + esc(r.roll_no || "-") + "</td>" +
        "<td>" + esc(r.full_name) + "</td>" +
        '<td class="num">' + r.tests_given + "</td>" +
        '<td class="num">' + r.obtained + " / " + r.total + "</td>" +
        '<td class="num"><b>' + Number(r.percentage).toFixed(2) + "%</b></td>" +
        '<td class="num"><b>' + esc(r.grade) + "</b></td>" +
        '<td class="num">' + esc(r.result) + "</td>" +
        "</tr>";
    }).join("") || '<tr><td colspan="8">There are no students in this class.</td></tr>';
    qs("vrTable").classList.remove("hidden");
    showMsg(msg, data.rows.length + " students' result loaded.", true);
  } catch (err) {
    showMsg(msg, err.message, false);
  }
});

/* ---------- 6. Attendance Report ---------- */
qs("attRepLoad").addEventListener("click", async function () {
  const msg = qs("attRepMsg");
  clearMsg(msg);
  const cls = qs("attRepClass").value;
  const from = qs("attFrom").value;
  const to = qs("attTo").value;
  if (!cls || !from || !to) { showMsg(msg, "Class, from date and to date are required.", false); return; }
  try {
    const rows = await api(
      "api/attendance.php?action=summary&class=" + encodeURIComponent(cls) +
      "&from=" + from + "&to=" + to
    );
    qs("attRepBody").innerHTML = rows.map(function (r) {
      const pct = r.percentage == null ? "0.0" : Number(r.percentage).toFixed(1);
      return "<tr>" +
        "<td>" + esc(r.roll_no || "-") + "</td>" +
        "<td>" + esc(r.full_name) + "</td>" +
        '<td class="num">' + r.present_days + "</td>" +
        '<td class="num">' + r.absent_days + "</td>" +
        '<td class="num">' + r.late_days + "</td>" +
        '<td class="num">' + r.leave_days + "</td>" +
        '<td class="num">' + r.total_days + "</td>" +
        '<td class="num"><b>' + pct + "%</b></td>" +
        "</tr>";
    }).join("") || '<tr><td colspan="8">No records found.</td></tr>';
    qs("attRepTable").classList.remove("hidden");
  } catch (err) {
    showMsg(msg, err.message, false);
  }
});

/* ---------- 7. Homework Upload ---------- */
let hwPdfUploading = false;

function hwClassLabel(cls) {
  return (cls === "Nursery" || cls === "KG") ? cls : "Class " + cls;
}

qs("hwPdf").addEventListener("change", async function () {
  const file = this.files[0];
  const info = qs("hwFileInfo");
  if (!file) {
    qs("hwFileUrl").value = "";
    info.style.display = "none";
    return;
  }
  info.style.display = "block";
  info.textContent = "Uploading PDF...";
  hwPdfUploading = true;
  const fd = new FormData();
  fd.append("file", file);
  try {
    const data = await api("api/upload.php?action=upload_pdf", { method: "POST", body: fd });
    qs("hwFileUrl").value = data.url;
    info.textContent = "PDF saved to the backend: " + data.url;
  } catch (err) {
    qs("hwFileUrl").value = "";
    info.textContent = "PDF upload failed: " + err.message;
  } finally {
    hwPdfUploading = false;
  }
});

async function loadHomeworkAdmin() {
  const body = qs("hwTableBody");
  try {
    const rows = await api("api/homework.php?action=list");
    body.innerHTML = rows.map(function (h) {
      const file = h.file_url
        ? '<a href="' + esc(h.file_url) + '" target="_blank" rel="noopener">View PDF</a>'
        : "-";
      return "<tr>" +
        "<td>" + (h.type === "test" ? "Test" : "Homework") + "</td>" +
        "<td>" + esc(hwClassLabel(h.class_level)) + "</td>" +
        "<td>" + esc(h.subject) + "</td>" +
        "<td>" + esc(h.title) + "</td>" +
        "<td>" + esc(h.assigned_date || "-") + "</td>" +
        "<td>" + esc(h.due_date || "-") + "</td>" +
        "<td>" + file + "</td>" +
        '<td><button type="button" class="photo-edit hw-delete" data-id="' + esc(h.id) + '">Delete</button></td>' +
        "</tr>";
    }).join("") || '<tr><td colspan="8">No homework uploaded yet.</td></tr>';
  } catch (err) {
    body.innerHTML = '<tr><td colspan="8">' + esc(err.message) + "</td></tr>";
  }
}

qs("hwForm").addEventListener("submit", async function (e) {
  e.preventDefault();
  const msg = qs("hwMsg");
  clearMsg(msg);
  if (hwPdfUploading) {
    showMsg(msg, "PDF is uploading, please wait.", false);
    return;
  }
  try {
    const data = await postForm("api/homework.php?action=add", {
      type: qs("hwType").value,
      class_level: qs("hwClass").value,
      subject: qs("hwSubject").value.trim(),
      title: qs("hwTitle").value.trim(),
      description: qs("hwDescription").value.trim(),
      assigned_date: qs("hwAssigned").value,
      due_date: qs("hwDue").value,
      file_url: qs("hwFileUrl").value
    });
    showMsg(msg, data.message, data.success);
    if (data.success) {
      e.target.reset();
      qs("hwFileUrl").value = "";
      qs("hwFileInfo").style.display = "none";
      qs("hwAssigned").value = today();
      loadHomeworkAdmin();
    }
  } catch (err) {
    showMsg(msg, err.message, false);
  }
});

qs("hwTableBody").addEventListener("click", async function (e) {
  const btn = e.target.closest(".hw-delete");
  if (!btn) return;
  if (!confirm("Delete this homework? The uploaded PDF will also be removed.")) return;
  const msg = qs("hwMsg");
  clearMsg(msg);
  try {
    const data = await postForm("api/homework.php?action=delete", { id: btn.dataset.id });
    showMsg(msg, data.message, data.success);
    if (data.success) loadHomeworkAdmin();
  } catch (err) {
    showMsg(msg, err.message, false);
  }
});

/* ---------- 8. 1 Month Test Sheet ---------- */
qs("msClassNo").addEventListener("input", function () {
  const code = this.value.trim().toLowerCase();
  let found = "";
  CLASSES.forEach(function (c) {
    if (classNumber(c).toLowerCase() === code) found = c;
  });
  qs("msClass").value = found;
});

qs("msClass").addEventListener("change", function () {
  qs("msClassNo").value = this.value ? classNumber(this.value) : "";
});

qs("msClear").addEventListener("click", function () {
  qs("msClassNo").value = "";
  qs("msClass").value = "";
  qs("msRoll").value = "";
  qs("msName").value = "";
  qs("msTableBody").innerHTML = "";
  qs("msResultCard").style.display = "none";
  clearMsg(qs("msMsg"));
});

qs("msForm").addEventListener("submit", async function (e) {
  e.preventDefault();
  const msg = qs("msMsg");
  clearMsg(msg);

  const code = qs("msClassNo").value.trim().toLowerCase();
  const cls = qs("msClass").value;
  const roll = qs("msRoll").value.trim().toLowerCase();
  const name = qs("msName").value.trim().toLowerCase();

  if (!code && !cls && !roll && !name) {
    showMsg(msg, "Class number, class, roll no ya student ka naam likhein.", false);
    return;
  }

  try {
    const students = await api("api/students.php?action=list");
    const rows = students.filter(function (s) {
      const classNo = classNumber(s.current_class).toLowerCase();
      if (code && classNo.indexOf(code) !== 0) return false;
      if (cls && String(s.current_class) !== cls) return false;
      if (roll && String(s.roll_no || "").toLowerCase().indexOf(roll) < 0) return false;
      if (name && String(s.full_name || "").toLowerCase().indexOf(name) < 0) return false;
      return true;
    });

    qs("msResultCard").style.display = "block";
    qs("msTableBody").innerHTML = rows.map(function (s) {
      return "<tr>" +
        "<td>" + esc(s.full_name) + "</td>" +
        "<td>" + esc(s.admission_id) + "</td>" +
        "<td>" + esc(s.current_class) + "</td>" +
        "<td><b>" + esc(classNumber(s.current_class) || "-") + "</b></td>" +
        "<td>" + esc(s.roll_no || "-") + "</td>" +
        "<td>" + esc(s.section || "-") + "</td>" +
        '<td><button type="button" class="photo-edit ms-view" data-id="' + esc(s.id) + '">1 Month Sheet</button></td>' +
        "</tr>";
    }).join("") || '<tr><td colspan="7">Is class number / roll no / naam ka koi student nahi mila.</td></tr>';

    showMsg(msg, rows.length + " student" + (rows.length === 1 ? "" : "s") + " found. \"1 Month Sheet\" par click karein.", true);

    // Agar sirf ek student mila ho to sheet khud khul jaye.
    if (rows.length === 1) openStudentProfile(rows[0].id);
  } catch (err) {
    showMsg(msg, err.message, false);
  }
});

qs("msTableBody").addEventListener("click", function (e) {
  const btn = e.target.closest(".ms-view");
  if (btn) openStudentProfile(btn.dataset.id);
});

/* ---------- Start ---------- */
document.addEventListener("DOMContentLoaded", async function () {
  // Check login first: do not show the admin panel without logging in
  try {
    var res = await fetch("api/auth.php?action=check");
    var auth = await res.json();
    if (!auth.logged_in) { window.location.replace("login.html"); return; }
    var who = qs("adminWho");
    if (who) who.textContent = (auth.user.full_name || auth.user.username) + " (" + auth.user.role + ")";
  } catch (e) {
    window.location.replace("login.html");
    return;
  }

  var lg = qs("logoutLink");
  if (lg) lg.addEventListener("click", async function (e) {
    e.preventDefault();
    await fetch("api/auth.php?action=logout", { method: "POST" });
    window.location.href = "login.html";
  });

  ["stuClass", "tClass", "ruClass", "attClass", "vrClass", "attRepClass", "hwClass"].forEach(function (id) {
    fillClasses(qs(id));
  });
  fillClassFilter(qs("msClass"));
  qs("attDate").value = today();
  qs("attFrom").value = today();
  qs("attTo").value = today();
  qs("tDate").value = today();
  qs("hwAssigned").value = today();
  syncStuClassNo();
  qs("stuClass").addEventListener("change", syncStuClassNo);
  loadHomeworkAdmin().catch(function () {
    qs("hwTableBody").innerHTML = '<tr><td colspan="8">Homework could not be loaded. Is XAMPP MySQL running?</td></tr>';
  });
  qs("ruClass").addEventListener("change", function () {
    loadTestsForUpload().catch(function () {});
  });
  loadStudentsList().catch(function () {
    qs("stuTableBody").innerHTML = '<tr><td colspan="9">Students could not be loaded. Is XAMPP MySQL running? Has the database been imported?</td></tr>';
  });
});
