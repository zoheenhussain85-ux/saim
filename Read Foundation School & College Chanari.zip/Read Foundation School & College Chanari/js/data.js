/* Read Foundation School Chanari - helper functions & constants
   Data (students, marks, attendance) comes from the backend: api/*.php */

const CLASSES = ["Nursery", "KG", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"];

const LEVELS = {
  "Primary": ["Nursery", "KG", "1", "2", "3", "4", "5"],
  "Middle": ["6", "7", "8"],
  "High School": ["9", "10"],
  "College": ["11", "12"]
};

function levelOf(cls) {
  for (const lv in LEVELS) if (LEVELS[lv].includes(cls)) return lv;
  return "";
}

function classLabel(c) {
  return (c === "Nursery" || c === "KG") ? c : "Class " + c;
}

const HIGH_SCHOOL_GROUPS = ["Arts", "Science"];
const COLLEGE_GROUPS = ["ICS", "Pre-Medical", "Pre-Engineering", "Economics"];

function groupsFor(level) {
  if (level === "High School") return HIGH_SCHOOL_GROUPS;
  if (level === "College") return COLLEGE_GROUPS;
  return [];
}

/* Backend grade scale: A+ 80+, A 70+, B 60+, C 50+, D 40+, otherwise F */
function gradeFor(pct) {
  if (pct >= 80) return { letter: "A+", cls: "grade-A" };
  if (pct >= 70) return { letter: "A", cls: "grade-A" };
  if (pct >= 60) return { letter: "B", cls: "grade-B" };
  if (pct >= 50) return { letter: "C", cls: "grade-C" };
  if (pct >= 40) return { letter: "D", cls: "grade-D" };
  return { letter: "F", cls: "grade-F" };
}

function remarkFor(pct) {
  if (pct >= 90) return "Outstanding";
  if (pct >= 80) return "Excellent";
  if (pct >= 70) return "Very Good";
  if (pct >= 60) return "Good";
  if (pct >= 50) return "Satisfactory";
  if (pct >= 40) return "Pass";
  return "Fail - Work Hard";
}

function esc(value) {
  return String(value == null ? "" : value).replace(/[&<>"']/g, function (ch) {
    return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch];
  });
}

/* Small helper to get JSON data from the backend */
async function apiJson(url, options) {
  const res = await fetch(url, options);
  let data = null;
  try { data = await res.json(); } catch (e) { data = null; }
  if (!res.ok || !data) throw new Error("No response from the server. Is XAMPP running and the database imported?");
  return data;
}

function postForm(url, obj) {
  const fd = new FormData();
  Object.keys(obj).forEach(function (k) {
    if (obj[k] !== undefined && obj[k] !== null) fd.append(k, obj[k]);
  });
  return apiJson(url, { method: "POST", body: fd });
}

function postJson(url, obj) {
  return apiJson(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(obj)
  });
}
