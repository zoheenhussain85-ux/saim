/* Read Foundation School Chanari - test report page (data from the backend) */

(async function () {
  const classSel = document.getElementById("trClass");
  const rollInput = document.getElementById("trRoll");
  const lookupForm = document.getElementById("lookupForm");
  const msg = document.getElementById("trMsg");
  const reportBox = document.getElementById("reportBox");

  const mfClass = document.getElementById("mfClass");
  const mfSection = document.getElementById("mfSection");
  const mfGroup = document.getElementById("mfGroup");
  const mfGroupWrap = document.getElementById("mfGroupWrap");
  const mfStudent = document.getElementById("mfStudent");
  const mfMsg = document.getElementById("mfMsg");
  const marksForm = document.getElementById("marksForm");

  const studentCache = {};

  function fillClassOptions(select, placeholder) {
    select.innerHTML = "";
    if (placeholder) {
      const o = document.createElement("option");
      o.value = ""; o.textContent = placeholder;
      select.appendChild(o);
    }
    CLASSES.forEach(c => {
      const o = document.createElement("option");
      o.value = c;
      o.textContent = classLabel(c);
      select.appendChild(o);
    });
  }

  fillClassOptions(classSel, "-- Select Class --");
  fillClassOptions(mfClass, "-- Select Class --");

  function showMessage(el, text, ok) {
    el.className = "msg " + (ok ? "ok" : "err");
    el.innerHTML = text;
  }

  function genderLabel(g) {
    if (g === "male") return "Boy";
    if (g === "female") return "Girl";
    return g || "-";
  }

  async function studentsFor(cls) {
    if (!cls) return [];
    if (!studentCache[cls]) {
      const rows = await apiJson("api/students.php?action=list&class=" + encodeURIComponent(cls));
      studentCache[cls] = Array.isArray(rows) ? rows : [];
    }
    return studentCache[cls];
  }

  function serialOf(list, student) {
    const i = list.findIndex(s => String(s.roll_no) === String(student.roll_no));
    return i >= 0 ? i + 1 : 1;
  }

  function renderReport(data, serial) {
    const student = data.student;
    const reports = data.reports || [];
    const images = data.report_images || [];
    const sum = data.summary || { obtained: 0, total: 0, percentage: 0, grade: "F", result: "FAIL" };
    const pass = sum.result === "PASS";

    let rows = "";
    reports.forEach(r => {
      const pct = Number(r.percentage) || 0;
      const g = gradeFor(pct);
      rows += `<tr>
        <td>${esc(r.subject || r.test_name)}</td>
        <td class="num">${esc(r.marks_obtained)}</td>
        <td class="num">${esc(r.total_marks)}</td>
        <td class="num">${pct.toFixed(1)}%</td>
        <td class="num ${g.cls}">${esc(r.grade || g.letter)}</td>
      </tr>`;
    });

    const imagesHtml = images.length ? `
      <div style="padding:6px 22px 16px;">
        <b>Marks Sheet Photo</b>
        <div style="display:flex;gap:12px;flex-wrap:wrap;margin-top:8px;">
          ${images.map(src => `<a href="${esc(src)}" target="_blank"><img src="${esc(src)}" alt="Marks Sheet" style="width:160px;border-radius:8px;border:1px solid #ddd;" /></a>`).join("")}
        </div>
      </div>` : "";

    reportBox.className = "report show";
    reportBox.innerHTML = `
      <div class="report-head">
        <div>
          <h3>${SCHOOL.name}</h3>
          <div class="due">${SCHOOL.address}</div>
        </div>
        <div style="text-align:right;">
          <b>${esc((data.exam_names && data.exam_names[0]) || "Test Report")}</b>
          <div class="due">${esc(student.date_of_admission || "")}</div>
        </div>
      </div>
      <div class="report-meta">
        <div><span>Student Name</span><b>${esc(student.full_name)}</b></div>
        <div><span>Father Name</span><b>${esc(student.parent_name || "-")}</b></div>
        <div><span>Gender</span><b>${genderLabel(student.gender)}</b></div>
        <div><span>Class</span><b>${classLabel(student.current_class)}</b></div>
        <div><span>Section</span><b>${esc(student.section || "-")}</b></div>
        ${student.student_group ? `<div><span>Group</span><b>${esc(student.student_group)}</b></div>` : ""}
        <div><span>Roll No</span><b>${serial}</b></div>
        <div><span>Admission ID</span><b>${esc(student.admission_id || "-")}</b></div>
      </div>
      ${rows ? `
      <table class="marks">
        <thead>
          <tr><th>Subject</th><th class="num">Obtained</th><th class="num">Total</th><th class="num">%</th><th class="num">Grade</th></tr>
        </thead>
        <tbody>${rows}</tbody>
      </table>` : `<div style="padding:20px;color:#c0392b;font-weight:600;">No marks have been entered for this student yet. Marks are uploaded from the "Result / Test Report Upload" tab in the Admin panel.</div>`}
      ${imagesHtml}
      <div class="report-foot">
        <div class="big-stat"><b>${sum.obtained}/${sum.total}</b><span>Total Marks</span></div>
        <div class="big-stat"><b>${Number(sum.percentage).toFixed(1)}%</b><span>Percentage</span></div>
        <div class="big-stat"><b class="${gradeFor(sum.percentage).cls}">${esc(sum.grade)}</b><span>Grade</span></div>
        <div class="big-stat"><b style="color:${pass ? '#1a7f37' : '#c0392b'}">${pass ? "PASS" : "FAIL"}</b><span>Result</span></div>
        <div class="big-stat"><b>${remarkFor(Number(sum.percentage))}</b><span>Remarks</span></div>
        <div class="stamp">${pass ? "PASSED" : "REAPPEAR"}</div>
      </div>`;
    reportBox.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  async function loadReport(cls, roll) {
    const data = await apiJson("api/test_reports.php?action=student_report&class=" +
      encodeURIComponent(cls) + "&roll=" + encodeURIComponent(roll));
    if (!data.success) throw new Error(data.message || "Student not found.");
    const list = await studentsFor(cls);
    renderReport(data, serialOf(list, data.student));
    return data;
  }

  /* ---------- Report by roll number ---------- */
  lookupForm.addEventListener("submit", async function (e) {
    e.preventDefault();
    const cls = classSel.value;
    const roll = rollInput.value.trim();
    if (!cls) { showMessage(msg, "Please select a class.", false); return; }
    if (!roll) { showMessage(msg, "Enter a roll number.", false); return; }
    try {
      const data = await loadReport(cls, roll);
      showMessage(msg, "Report loaded for <b>" + esc(data.student.full_name) + "</b>.", true);
    } catch (err) {
      reportBox.className = "report";
      reportBox.innerHTML = "";
      showMessage(msg, esc(err.message), false);
    }
  });

  /* ---------- Report by student name ---------- */
  function updateMfGroup() {
    const groups = groupsFor(levelOf(mfClass.value));
    if (!groups.length) {
      mfGroupWrap.style.display = "none";
      mfGroup.innerHTML = '<option value="ALL">All</option>';
    } else {
      mfGroupWrap.style.display = "";
      mfGroup.innerHTML = '<option value="ALL">All</option>' +
        groups.map(g => `<option value="${g}">${g}</option>`).join("");
    }
  }

  function matchSection(s) {
    const sec = mfSection.value;
    if (sec === "ALL") return true;
    return genderLabel(s.gender) === sec;
  }

  function matchGroup(s) {
    if (mfGroupWrap.style.display === "none" || mfGroup.value === "ALL") return true;
    return (s.student_group || "") === mfGroup.value;
  }

  async function loadStudents() {
    if (!mfClass.value) {
      mfStudent.innerHTML = '<option value="">-- Select class first --</option>';
      return;
    }
    mfStudent.innerHTML = '<option value="">-- Loading... --</option>';
    try {
      const list = (await studentsFor(mfClass.value)).filter(matchSection).filter(matchGroup);
      if (!list.length) {
        mfStudent.innerHTML = '<option value="">-- No students found --</option>';
      } else {
        mfStudent.innerHTML = '<option value="">-- Select Student --</option>' +
          list.map(s => `<option value="${esc(s.roll_no)}">${esc(s.roll_no)} - ${esc(s.full_name)}${s.student_group ? " (" + esc(s.student_group) + ")" : ""}</option>`).join("");
      }
    } catch (err) {
      mfStudent.innerHTML = '<option value="">-- Students could not be loaded --</option>';
      showMessage(mfMsg, esc(err.message), false);
    }
  }

  mfClass.addEventListener("change", function () { updateMfGroup(); loadStudents(); });
  mfSection.addEventListener("change", loadStudents);
  mfGroup.addEventListener("change", loadStudents);

  mfStudent.addEventListener("change", async function () {
    if (!mfStudent.value) return;
    try {
      const data = await loadReport(mfClass.value, mfStudent.value);
      showMessage(mfMsg, "Report loaded for <b>" + esc(data.student.full_name) + "</b>.", true);
    } catch (err) {
      showMessage(mfMsg, esc(err.message), false);
    }
  });

  marksForm.addEventListener("submit", async function (e) {
    e.preventDefault();
    if (!mfStudent.value) { showMessage(mfMsg, "Please select a student first.", false); return; }
    try {
      const data = await loadReport(mfClass.value, mfStudent.value);
      showMessage(mfMsg, "Report loaded for <b>" + esc(data.student.full_name) + "</b>.", true);
    } catch (err) {
      showMessage(mfMsg, esc(err.message), false);
    }
  });

  updateMfGroup();
})();
