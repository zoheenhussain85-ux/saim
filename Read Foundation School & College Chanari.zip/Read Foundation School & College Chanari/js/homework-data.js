/* Read Foundation School Chanari - Homework & Test list
   Add / edit entries here.

   type        : "test" or "homework"
   class       : any class from CLASSES (Nursery, KG, 1 ... 12)
   subject     : Subject name
   title       : Test / homework title
   description : Instructions for the student
   assigned    : Date assigned (YYYY-MM-DD)
   due         : Submission deadline (YYYY-MM-DD)
   pdf         : Path to the PDF, e.g. "uploads/homework/file.pdf"
                 Keep an empty string "" if there is no PDF.
*/

const HOMEWORK_DATA = [
  {
    id: 1,
    type: "test",
    class: "5",
    subject: "Mathematics",
    title: "Fractions Class Test",
    description: "Chapter 3 (Fractions) test paper. Solve questions 1 to 10. You must show it to the teacher the day before the test.",
    assigned: "2026-11-10",
    due: "2026-11-12",
    pdf: "uploads/homework/class5-math-fractions-test.pdf"
  },
  {
    id: 2,
    type: "homework",
    class: "5",
    subject: "English",
    title: "Essay: My School",
    description: "Write a 10-line essay about your school. Keep the paragraphs clean and neat. Include a heading and the student's name.",
    assigned: "2026-11-10",
    due: "2026-11-12",
    pdf: "uploads/homework/class5-english-essay-homework.pdf"
  },
  {
    id: 3,
    type: "test",
    class: "8",
    subject: "Science",
    title: "Force and Motion Test",
    description: "Chapter 5 (Force and Motion) test. Includes both short questions and numericals. You may keep a formula sheet with you.",
    assigned: "2026-11-09",
    due: "2026-11-13",
    pdf: "uploads/homework/class8-science-force-test.pdf"
  },
  {
    id: 4,
    type: "homework",
    class: "8",
    subject: "Mathematics",
    title: "Algebra Practice",
    description: "Solve questions 1 to 12 of Exercise 4.1 in your copy. Write every step clearly.",
    assigned: "2026-11-09",
    due: "2026-11-11",
    pdf: ""
  },
  {
    id: 5,
    type: "test",
    class: "10",
    subject: "Physics",
    title: "Numericals Test",
    description: "Chapter 4 numericals test. Solve according to the steps given in the question paper and do not forget to write units.",
    assigned: "2026-11-08",
    due: "2026-11-12",
    pdf: "uploads/homework/class10-physics-numericals-test.pdf"
  },
  {
    id: 6,
    type: "homework",
    class: "10",
    subject: "English",
    title: "Letter to Editor",
    description: "Write a letter to the editor of a local newspaper about road cleanliness. Keep the format and tone formal.",
    assigned: "2026-11-08",
    due: "2026-11-11",
    pdf: ""
  },
  {
    id: 7,
    type: "test",
    class: "9",
    subject: "Computer Science",
    title: "HTML Basics Practical",
    description: "Practical test on basic HTML tags. Demonstrate the use of headings, paragraphs, lists and images in the computer lab.",
    assigned: "2026-11-07",
    due: "2026-11-10",
    pdf: ""
  },
  {
    id: 8,
    type: "homework",
    class: "11",
    subject: "Chemistry",
    title: "Periodic Table Notes",
    description: "Make notes on the groups and periods of the periodic table. Write the symbols and atomic numbers of the first 20 elements.",
    assigned: "2026-11-07",
    due: "2026-11-12",
    pdf: ""
  }
];
